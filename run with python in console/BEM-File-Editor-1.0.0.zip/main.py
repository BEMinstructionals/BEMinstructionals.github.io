# Copyright 2025 Mitchal Dichter
# 
# Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
# 
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
# 
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# 
# 
# The BEM Instructionals logo is licensed under a Creative Commons Attribution-ShareAlike 4.0 International license.
# https://creativecommons.org/licenses/by-sa/4.0/
# 
# PySide6 is licensed under the GNU Lesser General Public License version 3.
# https://www.gnu.org/licenses/lgpl-3.0.en.html#license-text

import copy
import os
import shutil
import sys
from datetime import datetime, UTC

import IDD_dictionaries
import IDF_object_defaults_dictionaries

from PySide6.QtCore import (
    QCommandLineParser,
    QDateTime,
    QFileInfo,
    QFileSystemWatcher,
    QProcess,
    QSettings,
    QStandardPaths,
    QSysInfo,
    QUrl,
    Qt,
)

from PySide6.QtGui import (
    QAction,
    QActionGroup,
    QBrush,
    QCloseEvent,
    QColor,
    QDesktopServices,
    QFont,
    QIcon,
    QKeyEvent,
    QKeySequence,
    QWheelEvent,
)

from PySide6.QtNetwork import (
    QNetworkAccessManager,
    QNetworkReply,
    QNetworkRequest,
)

from PySide6.QtWidgets import (
    QApplication,
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPushButton,
    QRadioButton,
    QSplitter,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QToolBar,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        #conversions taken from the IDD file
        #best attempt to find the method to the madness
        #\units _ \ip-units_OR_BLANK : [best_guess_ip_units, multiplier, adder]
        #special case hh:mm with has None for multiplier and adder
        self.unit_conversions_dict = {
            "$_":["$",1,0],
            "$/(W/K)_":["$/(Btu/h-F)",0.52667614683731,0],
            "$/(m3/s)_":["$/(ft3/min)",0.000472000059660808,0],
            "$/kW_":["$/(kBtuh/h)",0.293083235638921,0],
            "$/m2_":["$/ft2",0.0928939733269818,0],
            "$/m3_":["$/ft3",0.0283127014102352,0],
            "(kg/s)/W_":["(lbm/sec)/(Btu/hr)",0.646078115385742,0],
            "1/K_":["1/F",0.555555555555556,0],
            "1/hr_":["1/hr",1,0],
            "1/m_":["1/ft",0.3048,0],
            "A_":["A",1,0],
            "A/K_":["A/F",0.555555555555556,0],
            "Ah_":["Ah",1,0],
            "C_":["F",1.8,32],
            "C_F":["F",1.8,32],
            "GJ_":["ton-hrs",78.9889415481832,0],
            "GJ_ton-hrs":["ton-hrs",78.9889415481832,0],
            "J_":["Wh",0.000277777777777778,0],
            "J/J_":["J/J",1,0],
            "J/kg_":["Btu/lb",0.00042986,7.686],
            "J/kg-K_":["Btu/lb-F",0.000239005736137667,0],
            "J/kg-K2_":["Btu/lb-F2",0.000132889924714692,0],
            "J/kg-K3_":["Btu/lb-F3",7.38277359526066e-05,0],
            "J/m2-K_":["Btu/ft2-F",4.89224766847393e-05,0],
            "J/m3-K_":["Btu/ft3-F",1.49237004739337e-05,0],
            "K/m_":["F/ft",0.54861322767449,0],
            "L/MJ_":["gal/kWh",0.951022349025202,0],
            "L/day_":["pint/day",2.11337629827348,0],
            "L/kWh_":["pint/kWh",2.11337629827348,0],
            "N-m_":["lbf-in",8.85074900525547,0],
            "Pa_":["psi",0.000145037743897283,0],
            "Pa_Pa":["Pa",1,0],
            "Pa_ftH2O":["ftH2O",0.00033455,0],
            "Pa_inH2O":["inH2O",0.00401463,0],
            "Pa_inHg":["inHg",0.00029613,0],
            "V_":["V",1,0],
            "V/K_":["V/F",0.555555555555556,0],
            "VA_":["VA",1,0],
            "W_":["Btu/h",3.4121412858518,0],
            "W_Btu/h":["Btu/h",3.4121412858518,0],
            "W_W":["W",1,0],
            "W/((m3/s)-Pa)_W/((ft3/min)-inH2O)":["W/((ft3/min)-inH2O)",0.117556910599482,0],
            "W/((m3/s)-Pa)_W/((gal/min)-ftH20)":["W/((gal/min)-ftH20)",0.188582274697355,0],
            "W/(m3/s)_":["W/(ft3/min)",0.0004719475,0],
            "W/(m3/s)_W/(ft3/min)":["W/(ft3/min)",0.0004719475,0],
            "W/(m3/s)_W/(gal/min)":["W/(gal/min)",6.30902e-05,0],
            "W/K_":["Btu/h-F",1.89563404769544,0],
            "W/W_":["W/W",1,0],
            "W/m_":["Btu/h-ft",1.04072,0],
            "W/m-K_":["Btu-in/h-ft2-F",6.93481276005548,0],
            "W/m-K_Btu/h-ft-F":["Btu/h-ft-F",0.577796066000163,0],
            "W/m-K2_":["Btu/h-F2-ft",0.321418310071648,0],
            "W/m-K3_":["Btu/h-F3-ft",0.178565727817582,0],
            "W/m2_":["Btu/h-ft2",0.316957210776545,0],
            "W/m2, W or deg C_":["unknown",1,0],
            "W/m2, deg C or cd/m2_unknown":["unknown",1,0],
            "W/m2_Btu/h-ft2":["Btu/h-ft2",0.316957210776545,0],
            "W/m2_W/ft2":["W/ft2",0.09290304,0],
            "W/m2-K_":["Btu/h-ft2-F",0.176110194261872,0],
            "W/m2-K2_":["Btu/h-ft2-F2",0.097826,0],
            "W/person_Btu/h-person":["Btu/h-person",3.4121412858518,0],
            "W/person_W/person":["W/person",1,0],
            "W/s_":["W/s",1,0],
            "cm_":["in",0.3937,0],
            "cm2_":["inch2",0.15500031000062,0],
            "cycles/hr_":["cycles/hr",1,0],
            "days_":["days",1,0],
            "deg_":["deg",1,0],
            "deltaC_":["deltaF",1.8,0],
            "deltaC/hr_":["deltaF/hr",1.8,0],
            "deltaJ/kg_":["deltaBtu/lb",0.0004299,0],
            "dimensionless_":["dimensionless",1,0],
            "eV_":["eV",1,0],
            "g/MJ_":["lb/MWh",7.93664091373665,0],
            "g/mol_":["lb/mol",0.0022046,0],
            "hh:mm_":["hh:mm",None,None],
            "hr_":["hr",1,0],
            "kJ/kg_":["Btu/lb",0.429925,0],
            "kg_":["lb",2.2046,0],
            "kg/Pa-s-m2_":["lb/psi-s-ft2",1412.00523459398,0],
            "kg/kg_":["kg/kg",1,0],
            "kg/m_":["lb/ft",0.67196893069637,0],
            "kg/m-s_":["lb/ft-s",0.67196893069637,0],
            "kg/m-s-K_":["lb/ft-s-F",0.373316072609094,0],
            "kg/m-s-K2_":["lb/ft-s-F2",0.207397818116164,0],
            "kg/m2_":["lb/ft2",0.204794053596664,0],
            "kg/m3_":["lb/ft3",0.062428,0],
            "kg/s_":["lb/s",2.20462247603796,0],
            "kg/s-m_":["lb/s-ft",0.67196893069637,0],
            "kg/s2_":["lb/s2",2.2046,0],
            "kgWater/kgDryAir_":["kgWater/kgDryAir",1,0],
            "kmol_":["kmol",1,0],
            "kmol/s_":["kmol/s",1,0],
            "lux_":["foot-candles",0.092902267,0],
            "m_":["ft",3.28083989501312,0],
            "m_ft":["ft",3.28083989501312,0],
            "m_in":["in",39.3700787401575,0],
            "m/s_":["miles/hr",2.2369362920544,0],
            "m/s_miles/hr":["miles/hr",2.2369362920544,0],
            "m/yr_":["inch/yr",39.3700787401575,0],
            "m2_":["ft2",10.7639104167097,0],
            "m2_ft2":["ft2",10.7639104167097,0],
            "m2-K/W_":["ft2-F-hr/Btu",5.678263,0],
            "m2/m_":["ft2/ft",3.28083989501312,0],
            "m2/person_":["ft2/person",10.764961,0],
            "m2/s_":["ft2/s",10.7639104167097,0],
            "m3_":["ft3",35.3146667214886,0],
            "m3_gal":["gal",264.172037284185,0],
            "m3/MJ_":["ft3/kWh",127.13292,0],
            "m3/hr_gal/hr":["gal/hr",264.172037284185,0],
            "m3/hr-m2_gal/hr-ft2":["gal/hr-ft2",24.5423853466941,0],
            "m3/hr-person_gal/hr-person":["gal/hr-person",264.172037284185,0],
            "m3/m2_gal/ft2":["gal/ft2",24.5423853466941,0],
            "m3/m3_":["m3/m3",1,0],
            "m3/person_gal/person":["gal/person",264.172037284185,0],
            "m3/s_":["ft3/min",2118.88000328931,0],
            "m3/s_ft3/min":["ft3/min",2118.88000328931,0],
            "m3/s_gal/min":["gal/min",15850.3222370511,0],
            "m3/s-W_":["(ft3/min)/(Btu/h)",621.099127332943,0],
            "m3/s-W_(ft3/min)/(Btu/h)":["(ft3/min)/(Btu/h)",621.099127332943,0],
            "m3/s-W_(gal/min)/(Btu/h)":["(gal/min)/(Btu/h)",4645.27137336702,0],
            "m3/s-m_":["ft3/min-ft",645.89,0],
            "m3/s-m_ft3/min-ft":["ft3/min-ft",645.89,0],
            "m3/s-m_gal/min-ft":["gal/min-ft",4831.17821785317,0],
            "m3/s-m2_":["ft3/min-ft2",196.85,0],
            "m3/s-person_":["ft3/min-person",2118.6438,0],
            "micron_":["micron",1,0],
            "minutes_":["minutes",1,0],
            "ms_":["ms",1,0],
            "ohms_":["ohms",1,0],
            "percent_":["percent",1,0],
            "percent/K_":["percent/F",0.555555555555556,0],
            "person/m2_":["person/ft2",0.0928939733269818,0],
            "ppm_":["ppm",1,0],
            "rev/min_":["rev/min",1,0],
            "s_":["s",1,0],
            "s/m_":["s/ft",0.3048,0],
            "umol/m2-s_umol/ft2-s":["umol/ft2-s",0.09290304,0],
            "years_":["years",1,0]}
        
        #variables used in multiple places that don't change
        self.os_type = QSysInfo.productType()
        self.screen_height = QApplication.primaryScreen().geometry().height()
        self.screen_width = QApplication.primaryScreen().geometry().width()
        self.clipboard = QApplication.clipboard()
        self.company_name = "BEM Instructionals"
        self.version_dot_txt_BEM_File_Editor_url = "https://raw.githubusercontent.com/BEMinstructionals/BEMinstructionals.github.io/refs/heads/main/version.txt"
        self.website_downloads_section_url = "https://beminstructionals.com/index.html#id_Downloads"
        self.all_suported_EnergyPlus_versions = ["EnergyPlus 25.1","EnergyPlus 24.2","EnergyPlus 24.1","EnergyPlus 23.2","EnergyPlus 23.1","EnergyPlus 22.2","EnergyPlus 22.1",] #all EnergyPlus versions supported
        self.valid_object_field_brush = QBrush(QColor("#FFFFFF"))
        self.invalid_object_field_brush = QBrush(QColor("#F5C243"))
        self.unit_abbreviations = ["SI", "IP"]
        self.BEM_File_editor_version = QApplication.instance().applicationVersion()
        self.undo_redo_no_IDF_loaded_string = "No IDF Loaded"
        self.new_IDF_loaded_string = "New IDF File"
        self.undo_redo_IDF_state_from_drive_string = "IDF State from Drive"
        self.undo_redo_IDF_unsaved_changes_string = "IDF Unsaved Changes"
        self.undo_redo_IDF_file_changed_externally_string = "IDF File Changed Externally"
        self.EnergyPlus_program_working_directory_name = "EnergyPlus temp files"
        
        self.settings_defaults_dict = {
            "selected_EnergyPlus_version_string":self.all_suported_EnergyPlus_versions[0],
            "last_directory_viewed_string":"",
            "units_string":"SI",
            "show_python_console_tab_bool":False,
            "disable_update_prompt_bool":False,
            "font_point_size_int":9,
            "editor_splitter_int_list":[250,250,250], #pixel heights
            "editor_top_splitter_int_list":[300,300,300], #pixel widths
            "classes_tree_widget_column_widths_int_list":[200,50,50,50], #pixel widths
            "EnergyPlus_installation_directories_dict":{},
            "displayed_files_as_text_list":["<IDF FILE>.idf","eplusout.err"],
            "displayed_files_as_CSV_list": ["eplusout.eio"],
            "displayed_files_as_HTML_list":["eplustbl.htm"],
        }
        for EnergyPlus_version_string in self.all_suported_EnergyPlus_versions:
            version_string = EnergyPlus_version_string[11:15].replace(".","-")
            if self.os_type == "windows":
                self.settings_defaults_dict["EnergyPlus_installation_directories_dict"][EnergyPlus_version_string] = "C:/EnergyPlusV" + version_string + "-0/"
            elif self.os_type == "macos":
                self.settings_defaults_dict["EnergyPlus_installation_directories_dict"][EnergyPlus_version_string] = "/Applications/EnergyPlus-" + version_string + "-0/"
            elif self.os_type == "linux":
                self.settings_defaults_dict["EnergyPlus_installation_directories_dict"][EnergyPlus_version_string] = "/usr/local/EnergyPlus-" + version_string + "-0/"
            else:
                self.settings_defaults_dict["EnergyPlus_installation_directories_dict"][EnergyPlus_version_string] = ""
        
        #the settings_dict is set to defaults, overwritten with the QSettings file when the application is opened, is used during initial setup, and written to the QSettings file when the application closes
        self.settings_dict = {}
        #instantiate settings_dict to defaults in case QSettings read does not populate everything
        for key in self.settings_defaults_dict.keys():
            self.settings_dict[key] = self.settings_defaults_dict[key]
        #overwrite defaults with stuff from the QSettings file
        self.settings = QSettings(self.company_name, APPLICATION_NAME)
        for key in self.settings_dict.keys():
            #if the key doesn't exist the default value when self.settings was instantiated remains
            if self.settings.contains(key):
                #values are stored as strings and must be cast upon reading
                if "_bool" in key:
                    self.settings_dict[key] = self.settings.value(key, type=bool)
                elif "_int" in key:
                    if "_int_list" in key:
                        self.settings_dict[key] = self.settings.value(key, type=list)
                        self.settings_dict[key] = [int(int_string) for int_string in self.settings_dict[key]] #convert list of strings to list of ints
                    else:
                        self.settings_dict[key] = self.settings.value(key, type=int)
                elif "_float" in key:
                    self.settings_dict[key] = self.settings.value(key, type=float)
                else: #read as a string or dictionary of strings or list of strings
                    self.settings_dict[key] = self.settings.value(key)
        
        #special case to add missing EnergyPlus_version_string key to self.settings_dict["EnergyPlus_installation_directories_dict"]
        #if the old QSettings file doesn't have the new key, like a new install after an EnergyPlus release, then the dict from settings_defaults_dict is overwritten by QSettings which is missing the new EnergyPlus Version
        for EnergyPlus_version_string in self.settings_defaults_dict["EnergyPlus_installation_directories_dict"].keys():
            if EnergyPlus_version_string not in self.settings_dict["EnergyPlus_installation_directories_dict"].keys():
                self.settings_dict["EnergyPlus_installation_directories_dict"][EnergyPlus_version_string] = self.settings_defaults_dict["EnergyPlus_installation_directories_dict"][EnergyPlus_version_string]
        
        #these are for the current session and are written to the QSettings file on application close
        self.current_session_last_directory_viewed_string = self.settings_dict["last_directory_viewed_string"]
        self.current_session_units_string = self.settings_dict["units_string"]
        self.current_session_disable_update_prompt_bool = self.settings_dict["disable_update_prompt_bool"]
        self.current_session_show_python_console_tab_bool = self.settings_dict["show_python_console_tab_bool"]
        self.current_session_font_point_size_int = self.settings_dict["font_point_size_int"]
        self.current_session_EnergyPlus_installation_directories_dict = {}
        for EnergyPlus_version_string in self.all_suported_EnergyPlus_versions:
            self.current_session_EnergyPlus_installation_directories_dict[EnergyPlus_version_string] = self.settings_dict["EnergyPlus_installation_directories_dict"][EnergyPlus_version_string]
        self.current_session_displayed_files_as_text_list = self.settings_dict["displayed_files_as_text_list"]
        self.current_session_displayed_files_as_CSV_list = self.settings_dict["displayed_files_as_CSV_list"]
        self.current_session_displayed_files_as_HTML_list = self.settings_dict["displayed_files_as_HTML_list"]
        
        #font size must be set early to apply to all subsequently created widgets
        QApplication.setFont(QFont("Arial", self.current_session_font_point_size_int))
        
        #set window title
        self.setWindowTitle(APPLICATION_NAME)
        
        #the window icon will be applied to all windows
        window_icon_path = "_internal/bem_instructionals_CCbysa.ico"
        if self.os_type == "windows": #else the OS is "macos" or "linux" which don't have a window icon or the OS is unknown and the window icon won't be set
            QApplication.instance().setWindowIcon(QIcon(window_icon_path)) 
        
        #check for new BEM File Editor version
        self.available_BEM_File_Editor_version = "Unknown"
        self.manager = QNetworkAccessManager(self)
        self.reply = self.manager.get(QNetworkRequest(QUrl(self.version_dot_txt_BEM_File_Editor_url)))
        self.reply.finished.connect(self.on_finished)
        self.reply.readyRead.connect(self.on_ready_read)
        self.reply.errorOccurred.connect(self.on_error)
        
        #empty when application is opened
        self.IDD_dict = {}
        self.IDF_defaults_dict = {}
        self.IDF_dict = {}
        self.displayed_file_tabs_dict = {}
        self.hidden_object_indices = {}
        self.double_clicked_field_choice = None
        self.undo_history = []
        self.redo_history = []
        
        #needs self to keep reference to other window objects when instantiated, otherwise new windows close immediately
        self.popup_window = None
        
        #detect if the *.idf file is modified while open in the application
        self.idf_file_system_watcher = QFileSystemWatcher()
        self.idf_file_system_watcher.fileChanged.connect(self.opened_idf_file_changed_externally)
        
        #must keep a reference to the running process
        self.EnergyPlus_process = None
        #directory where EnergyPlus executable will create temporary files
        self.EnergyPlus_program_working_directory_path = None
        
        #create file menu
        menu = self.menuBar()
        
        file_menu = menu.addMenu("File")
        
        file_new_action = QAction("New", self)
        file_new_action.setShortcut(QKeySequence.StandardKey.New)
        file_new_action.triggered.connect(self.on_file_menu_new_click)
        file_menu.addAction(file_new_action)
        
        file_open_action = QAction("Open", self)
        file_open_action.setShortcut(QKeySequence.StandardKey.Open)
        file_open_action.triggered.connect(self.on_file_menu_open_click)
        file_menu.addAction(file_open_action)
        
        file_save_action = QAction("Save", self)
        file_save_action.setShortcut(QKeySequence.StandardKey.Save)
        file_save_action.triggered.connect(lambda: self.save_loaded_IDF_to_file("File->Save"))
        file_menu.addAction(file_save_action)
        
        file_save_as_action = QAction("Save As...", self)
        file_save_as_action.setShortcut(QKeySequence.StandardKey.SaveAs)
        file_save_as_action.triggered.connect(lambda: self.save_loaded_IDF_to_file("File->Save As"))
        file_menu.addAction(file_save_as_action)
        
        file_menu.addSeparator()
        
        file_simulate_IDF_action = QAction("Simulate IDF", self)
        file_simulate_IDF_action.setShortcut(QKeySequence("Shift+Space"))
        file_simulate_IDF_action.triggered.connect(self.on_file_menu_simulate_IDF_click)
        file_menu.addAction(file_simulate_IDF_action)
        
        file_unload_IDF_action = QAction("Unload IDF", self)
        file_unload_IDF_action.triggered.connect(self.on_file_menu_unload_IDF_click)
        file_menu.addAction(file_unload_IDF_action)
        
        file_unload_EPW_action = QAction("Unload EPW", self)
        file_unload_EPW_action.triggered.connect(self.on_file_menu_unload_EPW_click)
        file_menu.addAction(file_unload_EPW_action)
        
        file_menu.addSeparator()
        
        file_close_application_action = QAction("Close Application", self)
        file_close_application_action.triggered.connect(self.close)
        file_menu.addAction(file_close_application_action)
        
        edit_menu = menu.addMenu("Edit")
        
        edit_undo_action = QAction("Undo", self)
        edit_undo_action.setShortcut(QKeySequence.StandardKey.Undo)
        edit_undo_action.triggered.connect(lambda: self.undo_redo_operation("Undo"))
        edit_menu.addAction(edit_undo_action)
        
        edit_redo_action = QAction("Redo", self)
        edit_redo_action.setShortcut(QKeySequence.StandardKey.Redo)
        edit_redo_action.triggered.connect(lambda: self.undo_redo_operation("Redo"))
        edit_menu.addAction(edit_redo_action)
        
        edit_menu.addSeparator()
        
        edit_find_and_replace_text_action = QAction("Find and Replace Text", self)
        edit_find_and_replace_text_action.setShortcut(QKeySequence.StandardKey.Replace)
        #edit_find_and_replace_text_action.triggered.connect(self.on_edit_menu_find_and_replace_text_click)
        #edit_menu.addAction(edit_find_and_replace_text_action)
        
        view_menu = menu.addMenu("View")
        
        self.view_menu_units_top_action = QAction(self.unit_abbreviations[0] + " Units", self)
        self.view_menu_units_top_action.setCheckable(True)
        view_menu.addAction(self.view_menu_units_top_action)

        self.view_menu_units_bottom_action = QAction(self.unit_abbreviations[1] + " Units", self)
        self.view_menu_units_bottom_action.setCheckable(True)
        view_menu.addAction(self.view_menu_units_bottom_action)

        view_menu_units_action_group = QActionGroup(self)
        view_menu_units_action_group.setExclusive(True)
        view_menu_units_action_group.triggered.connect(self.on_units_action_group_triggered)
        view_menu_units_action_group.addAction(self.view_menu_units_top_action)
        view_menu_units_action_group.addAction(self.view_menu_units_bottom_action)
        
        if self.current_session_units_string == self.unit_abbreviations[0]:
            self.view_menu_units_top_action.setChecked(True)
        elif self.current_session_units_string == self.unit_abbreviations[1]:
            self.view_menu_units_bottom_action.setChecked(True)
        
        view_menu.addSeparator()
        
        self.view_menu_hide_empty_classes_action = QAction("Hide Empty Classes", self)
        self.view_menu_hide_empty_classes_action.setCheckable(True)
        self.view_menu_hide_empty_classes_action.setChecked(False)
        self.view_menu_hide_empty_classes_action.setShortcut(QKeySequence("Ctrl+L"))
        self.view_menu_hide_empty_classes_action.triggered.connect(self.on_view_menu_hide_empty_classes_triggered)
        view_menu.addAction(self.view_menu_hide_empty_classes_action)
        
        view_menu.addSeparator()
        
        view_menu_application_settings_window_action = QAction("Application Settings", self)
        view_menu_application_settings_window_action.triggered.connect(lambda: self.open_popup_window("Application Settings"))
        view_menu.addAction(view_menu_application_settings_window_action)
        
        #for macos that adds another item to the View menu
        view_menu.addSeparator()
        
        help_menu = menu.addMenu("Help")
        
        help_source_code_action = QAction(APPLICATION_NAME + " Source Code", self)
        help_source_code_action.triggered.connect(lambda: QDesktopServices.openUrl(QUrl("https://github.com/beminstructionals/beminstructionals.github.io")))
        help_menu.addAction(help_source_code_action)
        
        help_licenses_action = QAction(APPLICATION_NAME + " Licenses", self)
        help_licenses_action.triggered.connect(lambda: QMessageBox.information(self,
                "Licenses", 
                "The BEM File Editor main.py code is licensed under a BSD-3-Clause license.\nhttps://github.com/BEMinstructionals/BEMinstructionals.github.io/blob/main/LICENSE.md\n\nYou can access the source code at the GitHub repository.\nhttps://github.com/BEMinstructionals/BEMinstructionals.github.io\n\nThe BEM Instructionals logo is licensed under a Creative Commons Attribution-ShareAlike 4.0 International license.\nhttps://creativecommons.org/licenses/by-sa/4.0/\n\nPyside6 is licensed under the GNU Lesser General Public License version 3.\nhttps://www.gnu.org/licenses/lgpl-3.0.en.html#license-text"))
        help_menu.addAction(help_licenses_action)
        
        help_acknowledgments_action = QAction(APPLICATION_NAME + " Acknowledgments", self)
        help_acknowledgments_action.triggered.connect(lambda: QMessageBox.information(self,
                "Licenses", 
                "The IDF+ Editor by Matt Doiron was the inspiration for the BEM File Editor.\nhttps://github.com/mattdoiron/idfplus\n\nThanks for  and at  for \n\nA big Thank You! to all users who document and report bugs when they occur."))
        #help_menu.addAction(help_acknowledgments_action)
        
        help_menu.addSeparator()
        
        EnergyPlus_QuickStart_Webpage_action = QAction("EnergyPlus QuickStart Webpage", self)
        EnergyPlus_QuickStart_Webpage_action.triggered.connect(lambda: QDesktopServices.openUrl(QUrl("https://energyplus.net/quick-start")))
        help_menu.addAction(EnergyPlus_QuickStart_Webpage_action)
        
        EnergyPlus_Essentials_action = QAction("EnergyPlus Essentials", self)
        EnergyPlus_Essentials_action.triggered.connect(lambda: self.open_EnergyPlus_PDF("Documentation/EnergyPlusEssentials.pdf"))
        help_menu.addAction(EnergyPlus_Essentials_action)
        
        EnergyPlus_IO_Reference_action = QAction("EnergyPlus I/O Reference", self)
        EnergyPlus_IO_Reference_action.triggered.connect(lambda: self.open_EnergyPlus_PDF("Documentation/InputOutputReference.pdf"))
        help_menu.addAction(EnergyPlus_IO_Reference_action)
        
        EnergyPlus_Ouput_Details_and_Examples_action = QAction("EnergyPlus Output Details and Examples", self)
        EnergyPlus_Ouput_Details_and_Examples_action.triggered.connect(lambda: self.open_EnergyPlus_PDF("Documentation/OutputDetailsAndExamples.pdf"))
        help_menu.addAction(EnergyPlus_Ouput_Details_and_Examples_action)
        
        EnergyPlus_Engineering_Reference_action = QAction("EnergyPlus Engineering Reference", self)
        EnergyPlus_Engineering_Reference_action.triggered.connect(lambda: self.open_EnergyPlus_PDF("Documentation/EngineeringReference.pdf"))
        help_menu.addAction(EnergyPlus_Engineering_Reference_action)
        
        help_menu.addSeparator()
        
        EnergyPlus_Plant_Applications_Guide_action = QAction("EnergyPlus Plant Applications Guide", self)
        EnergyPlus_Plant_Applications_Guide_action.triggered.connect(lambda: self.open_EnergyPlus_PDF("Documentation/PlantApplicationGuide.pdf"))
        help_menu.addAction(EnergyPlus_Plant_Applications_Guide_action)
        
        EnergyPlus_EMS_Application_Guide_action = QAction("EnergyPlus EMS Application Guide", self)
        EnergyPlus_EMS_Application_Guide_action.triggered.connect(lambda: self.open_EnergyPlus_PDF("Documentation/EMSApplicationGuide.pdf"))
        help_menu.addAction(EnergyPlus_EMS_Application_Guide_action)
        
        Using_EnergyPlus_for_Compliance_action = QAction("Using EnergyPlus for Compliance", self)
        Using_EnergyPlus_for_Compliance_action.triggered.connect(lambda: self.open_EnergyPlus_PDF("Documentation/UsingEnergyPlusForCompliance.pdf"))
        help_menu.addAction(Using_EnergyPlus_for_Compliance_action)
        
        External_Interface_Application_Guide_action = QAction("External Interface Application Guide", self)
        External_Interface_Application_Guide_action.triggered.connect(lambda: self.open_EnergyPlus_PDF("Documentation/ExternalInterfacesApplicationGuide.pdf"))
        help_menu.addAction(External_Interface_Application_Guide_action)
        
        help_menu.addSeparator()
        
        EnergyPlus_Getting_Started_action = QAction("EnergyPlus Getting Started", self)
        EnergyPlus_Getting_Started_action.triggered.connect(lambda: self.open_EnergyPlus_PDF("Documentation/GettingStarted.pdf"))
        help_menu.addAction(EnergyPlus_Getting_Started_action)
        
        EnergyPlus_Auxiliary_Programs_action = QAction("EnergyPlus Auxiliary Programs", self)
        EnergyPlus_Auxiliary_Programs_action.triggered.connect(lambda: self.open_EnergyPlus_PDF("Documentation/AuxiliaryPrograms.pdf"))
        help_menu.addAction(EnergyPlus_Auxiliary_Programs_action)
        
        EnergyPlus_Acknowledgments_action = QAction("EnergyPlus Acknowledgments", self)
        EnergyPlus_Acknowledgments_action.triggered.connect(lambda: self.open_EnergyPlus_PDF("Documentation/Acknowledgments.pdf"))
        help_menu.addAction(EnergyPlus_Acknowledgments_action)
        
        help_menu.addSeparator()
        
        check_for_new_version_action = QAction("Check for New Version", self)
        check_for_new_version_action.triggered.connect(lambda: self.open_popup_window("Available Version"))
        help_menu.addAction(check_for_new_version_action)
        
        #create toolbar
        toolbar = QToolBar("Engine Arguments Toolbar")
        toolbar.setFloatable(False)
        toolbar.setMovable(False)
        self.addToolBar(toolbar)
        
        self.selected_EnergyPlus_version_combo_box = CustomComboBox()
        self.selected_EnergyPlus_version_combo_box.addItems(self.all_suported_EnergyPlus_versions)
        self.selected_EnergyPlus_version_combo_box.setCurrentText(self.settings_dict["selected_EnergyPlus_version_string"])
        self.selected_EnergyPlus_version_combo_box.setToolTip("Can only be changed when no IDF is loaded.")
        toolbar.addWidget(self.selected_EnergyPlus_version_combo_box)
        
        self.selected_IDF_path_line_edit = QLineEdit()
        self.selected_IDF_path_line_edit.setMaximumWidth(self.screen_width/4)
        self.selected_IDF_path_line_edit.setReadOnly(True)
        self.selected_IDF_path_line_edit.setPlaceholderText("Please open or create an IDF File")
        toolbar.addWidget(self.selected_IDF_path_line_edit)
        
        self.selected_EPW_path_line_edit = QLineEdit()
        self.selected_EPW_path_line_edit.setMaximumWidth(self.screen_width/4)
        self.selected_EPW_path_line_edit.setReadOnly(True)
        self.selected_EPW_path_line_edit.setPlaceholderText("Please pick an EPW File")
        self.selected_EPW_path_line_edit.setToolTip("EPW file used for EnergyPlus simulation.")
        toolbar.addWidget(self.selected_EPW_path_line_edit)
        
        pick_EPW_file_button = QPushButton("Pick EPW File")
        pick_EPW_file_button.pressed.connect(self.on_pick_EPW_file_click)
        toolbar.addWidget(pick_EPW_file_button)
        
        #create tabs
        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.TabPosition.North)
        self.tabs.setMovable(False)
        
        python_console_refresh_button = QPushButton("Refresh")
        python_console_refresh_button.pressed.connect(self.on_python_console_refresh_button_clicked)
        
        self.python_console_text_edit = QTextEdit()
        self.python_console_text_edit.setFont(QFont("Courier"))
        self.python_console_text_edit.setReadOnly(True)
        
        python_console_layout = QVBoxLayout()
        python_console_layout.addWidget(python_console_refresh_button)
        python_console_layout.addWidget(self.python_console_text_edit)
        
        self.python_console_widget = QWidget()
        self.python_console_widget.setLayout(python_console_layout)
        
        self.show_python_console_tab()
        
        EnergyPlus_console_v_layout = QVBoxLayout()
        self.EnergyPlus_console_tab_widget = QWidget()
        self.EnergyPlus_console_tab_widget.setLayout(EnergyPlus_console_v_layout)
        
        terminate_EnergyPlus_simulation_button = QPushButton("Terminate EnergyPlus Simulation")
        terminate_EnergyPlus_simulation_button.clicked.connect(self.on_terminate_EnergyPlus_simulation_button_clicked)
        EnergyPlus_console_v_layout.addWidget(terminate_EnergyPlus_simulation_button)
        
        self.EnergyPlus_console_text_edit = QTextEdit()
        self.EnergyPlus_console_text_edit.setReadOnly(True)
        self.stderr_text_color = QColor("red")
        stdout_color_hex_string = "#f0f0f0"
        self.stdout_text_color = QColor(stdout_color_hex_string)
        self.EnergyPlus_console_text_edit.setFont(QFont("Courier"))
        self.EnergyPlus_console_text_edit.setStyleSheet("background-color:#2b2b2b; color:" + stdout_color_hex_string + "; selection-background-color:#5c5c5c;")
        EnergyPlus_console_v_layout.addWidget(self.EnergyPlus_console_text_edit)

        self.tabs.addTab(self.EnergyPlus_console_tab_widget, "EnergyPlus console")
        
        self.filter_classes_line_edit = QLineEdit()
        self.filter_classes_line_edit.setPlaceholderText("Filter Classes by Text")
        self.filter_classes_line_edit.textEdited.connect(self.filter_class_tree_widget)
        self.show_empty_classes_radio_button = QRadioButton("Show")
        self.show_empty_classes_radio_button.setChecked(True)
        self.hide_empty_classes_radio_button = QRadioButton("Hide Empty Classes")
        self.show_hide_empty_classes_button_group = QButtonGroup()
        self.show_hide_empty_classes_button_group.addButton(self.show_empty_classes_radio_button)
        self.show_hide_empty_classes_button_group.addButton(self.hide_empty_classes_radio_button)
        self.show_hide_empty_classes_button_group.buttonToggled.connect(self.on_show_hide_empty_classes_button_group_toggled)
        
        self.filter_objects_line_edit = QLineEdit()
        self.filter_objects_line_edit.setPlaceholderText("Filter Objects by Field Text")
        self.filter_objects_line_edit.textEdited.connect(self.filter_class_tree_widget)
        self.filter_objects_case_sensitive_check_box = QCheckBox("Case Sensitive")
        self.filter_objects_case_sensitive_check_box.stateChanged.connect(self.filter_class_tree_widget)
        self.filter_objects_match_entire_field_text_check_box = QCheckBox("Match Entire Field Text")
        self.filter_objects_match_entire_field_text_check_box.stateChanged.connect(self.filter_class_tree_widget)
        
        
        self.classes_tree_widget = QTreeWidget()
        self.classes_tree_widget_headers_list = ["Object Class Name", "Top", "Bottom", "Count"]
        self.classes_tree_widget.setHeaderLabels(self.classes_tree_widget_headers_list)
        for column_index in range(len(self.classes_tree_widget_headers_list)):
            self.classes_tree_widget.setColumnWidth(column_index, self.settings_dict["classes_tree_widget_column_widths_int_list"][column_index])
        self.classes_tree_widget.itemClicked.connect(self.on_classes_tree_widget_item_clicked)
        
        object_info_title_label = QLabel("Object Information")
        self.object_info_text_edit = QTextEdit()
        self.object_info_text_edit.setPlaceholderText("Select a row in the Classes Tree")
        self.object_info_text_edit.setReadOnly(True)
        
        self.undo_redo_preview_window_button = QPushButton("Undo Redo Preview Window")
        self.undo_redo_preview_window_button.clicked.connect(lambda: self.open_popup_window("Undo Review Preview"))
        self.undo_text_edit = QTextEdit()
        self.undo_text_edit.setReadOnly(True)
        self.undo_button = QPushButton("Undo")
        self.undo_button.clicked.connect(lambda: self.undo_redo_operation("Undo"))
        self.undo_redo_IDF_status_label = QLabel()
        self.redo_button = QPushButton("Redo")
        self.redo_button.clicked.connect(lambda: self.undo_redo_operation("Redo"))
        self.redo_text_edit = QTextEdit()
        self.redo_text_edit.setReadOnly(True)
        
        self.undo_redo_operation(self.undo_redo_no_IDF_loaded_string)
        
        self.top_objects_table_widget_new_button = QPushButton("New")
        self.top_objects_table_widget_new_button.clicked.connect(lambda: self.on_table_object_button_clicked("Top", "New"))
        self.top_objects_table_widget_delete_button = QPushButton("Delete")
        self.top_objects_table_widget_delete_button.clicked.connect(lambda: self.on_table_object_button_clicked("Top", "Delete"))
        self.top_objects_table_widget_copy_button = QPushButton("Copy")
        self.top_objects_table_widget_copy_button.clicked.connect(lambda: self.on_table_object_button_clicked("Top", "Copy"))
        self.top_objects_table_widget_paste_button = QPushButton("Paste")
        self.top_objects_table_widget_paste_button.clicked.connect(lambda: self.on_table_object_button_clicked("Top", "Paste"))
        
        self.top_objects_table_widget_new_button.setEnabled(False)
        self.top_objects_table_widget_delete_button.setEnabled(False)
        self.top_objects_table_widget_copy_button.setEnabled(False)
        self.top_objects_table_widget_paste_button.setEnabled(False)
        
        self.top_objects_table_widget = QTableWidget()
        self.top_objects_table_widget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.top_objects_table_widget.customContextMenuRequested.connect(self.on_top_objects_table_widget_right_click)
        self.top_objects_table_widget.horizontalHeader().setVisible(False)
        self.top_objects_table_widget.cellChanged.connect(self.on_top_objects_table_widget_cell_changed)
        
        self.bottom_objects_table_widget_new_button = QPushButton("New")
        self.bottom_objects_table_widget_new_button.clicked.connect(lambda: self.on_table_object_button_clicked("Bottom", "New"))
        self.bottom_objects_table_widget_delete_button = QPushButton("Delete")
        self.bottom_objects_table_widget_delete_button.clicked.connect(lambda: self.on_table_object_button_clicked("Bottom", "Delete"))
        self.bottom_objects_table_widget_copy_button = QPushButton("Copy")
        self.bottom_objects_table_widget_copy_button.clicked.connect(lambda: self.on_table_object_button_clicked("Bottom", "Copy"))
        self.bottom_objects_table_widget_paste_button = QPushButton("Paste")
        self.bottom_objects_table_widget_paste_button.clicked.connect(lambda: self.on_table_object_button_clicked("Bottom", "Paste"))
        
        self.bottom_objects_table_widget_new_button.setEnabled(False)
        self.bottom_objects_table_widget_delete_button.setEnabled(False)
        self.bottom_objects_table_widget_copy_button.setEnabled(False)
        self.bottom_objects_table_widget_paste_button.setEnabled(False)
        
        self.bottom_objects_table_widget = QTableWidget()
        self.bottom_objects_table_widget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.bottom_objects_table_widget.customContextMenuRequested.connect(self.on_bottom_objects_table_widget_right_click)
        self.bottom_objects_table_widget.horizontalHeader().setVisible(False)
        self.bottom_objects_table_widget.cellChanged.connect(self.on_bottom_objects_table_widget_cell_changed)
        
        filter_classes_layout = QHBoxLayout()
        filter_classes_layout.addWidget(self.filter_classes_line_edit)
        filter_classes_layout.addWidget(self.show_empty_classes_radio_button)
        filter_classes_layout.addWidget(self.hide_empty_classes_radio_button)
        filter_classes_layout.setContentsMargins(0,0,0,0)
        
        filter_objects_layout = QHBoxLayout()
        filter_objects_layout.addWidget(self.filter_objects_line_edit)
        filter_objects_layout.addWidget(self.filter_objects_case_sensitive_check_box)
        filter_objects_layout.addWidget(self.filter_objects_match_entire_field_text_check_box)
        filter_objects_layout.setContentsMargins(0,0,0,0)
        
        filter_classes_widget = QWidget()
        filter_classes_widget.setLayout(filter_classes_layout)
        
        filter_objects_widget = QWidget()
        filter_objects_widget.setLayout(filter_objects_layout)
        
        editor_top_left_layout = QVBoxLayout()
        editor_top_left_layout.addWidget(filter_classes_widget)
        editor_top_left_layout.addWidget(filter_objects_widget)
        editor_top_left_layout.addWidget(self.classes_tree_widget)
        
        editor_top_left_widget = QWidget()
        editor_top_left_widget.setLayout(editor_top_left_layout)
        
        editor_top_middle_layout = QVBoxLayout()
        editor_top_middle_layout.addWidget(object_info_title_label)
        editor_top_middle_layout.addWidget(self.object_info_text_edit)
        
        editor_top_middle_widget = QWidget()
        editor_top_middle_widget.setLayout(editor_top_middle_layout)
        
        editor_top_right_layout = QVBoxLayout()
        editor_top_right_layout.addWidget(self.undo_redo_preview_window_button)
        editor_top_right_layout.addWidget(self.undo_text_edit)
        editor_top_right_layout.addWidget(self.undo_button)
        editor_top_right_layout.addWidget(self.undo_redo_IDF_status_label)
        editor_top_right_layout.addWidget(self.redo_button)
        editor_top_right_layout.addWidget(self.redo_text_edit)
        
        editor_top_right_widget = QWidget()
        editor_top_right_widget.setLayout(editor_top_right_layout)
        
        self.editor_top_splitter = QSplitter(Qt.Horizontal)
        self.editor_top_splitter.addWidget(editor_top_left_widget)
        self.editor_top_splitter.addWidget(editor_top_middle_widget)
        self.editor_top_splitter.addWidget(editor_top_right_widget)
        self.editor_top_splitter.setSizes(self.settings_dict["editor_top_splitter_int_list"])
        
        editor_middle_buttons_layout = QHBoxLayout()
        editor_middle_buttons_layout.addWidget(self.top_objects_table_widget_new_button)
        editor_middle_buttons_layout.addWidget(self.top_objects_table_widget_delete_button)
        editor_middle_buttons_layout.addWidget(self.top_objects_table_widget_copy_button)
        editor_middle_buttons_layout.addWidget(self.top_objects_table_widget_paste_button)
        editor_middle_buttons_layout.addStretch()
        editor_middle_buttons_layout.setContentsMargins(0,0,0,0)
        
        editor_middle_buttons_widget = QWidget()
        editor_middle_buttons_widget.setLayout(editor_middle_buttons_layout)
        
        editor_middle_layout = QVBoxLayout()
        editor_middle_layout.addWidget(editor_middle_buttons_widget)
        editor_middle_layout.addWidget(self.top_objects_table_widget)
        
        editor_middle_widget = QWidget()
        editor_middle_widget.setLayout(editor_middle_layout)
        
        editor_bottom_buttons_layout = QHBoxLayout()
        editor_bottom_buttons_layout.addWidget(self.bottom_objects_table_widget_new_button)
        editor_bottom_buttons_layout.addWidget(self.bottom_objects_table_widget_delete_button)
        editor_bottom_buttons_layout.addWidget(self.bottom_objects_table_widget_copy_button)
        editor_bottom_buttons_layout.addWidget(self.bottom_objects_table_widget_paste_button)
        editor_bottom_buttons_layout.addStretch()
        editor_bottom_buttons_layout.setContentsMargins(0,0,0,0)
        
        editor_bottom_buttons_widget = QWidget()
        editor_bottom_buttons_widget.setLayout(editor_bottom_buttons_layout)
        
        editor_bottom_layout = QVBoxLayout()
        editor_bottom_layout.addWidget(editor_bottom_buttons_widget)
        editor_bottom_layout.addWidget(self.bottom_objects_table_widget)
        
        editor_bottom_widget = QWidget()
        editor_bottom_widget.setLayout(editor_bottom_layout)
        
        self.editor_splitter = QSplitter(Qt.Vertical)
        self.editor_splitter.addWidget(self.editor_top_splitter)
        self.editor_splitter.addWidget(editor_middle_widget)
        self.editor_splitter.addWidget(editor_bottom_widget)
        self.editor_splitter.setSizes(self.settings_dict["editor_splitter_int_list"])
        
        self.tabs.addTab(self.editor_splitter, "Editor")
        
        self.load_displayed_file_tabs()
        
        self.setCentralWidget(self.tabs)
        
        #show Editor tab on application open
        self.tabs.setCurrentWidget(self.editor_splitter)
        
        #check for double clicking of *.idf file to open application, which will have a command line argument
        parser = QCommandLineParser()
        parser.addPositionalArgument("IDF_file", "IDF path input to open.")
        parser.process(app)
        arguments = parser.positionalArguments()
        
        if len(arguments) > 0:
            IDF_command_line_argument = arguments[0]
            IDF_file_info = QFileInfo(IDF_command_line_argument)
            #is this an IDF file
            if IDF_file_info.suffix().lower() == "idf" and IDF_file_info.exists():
                self.load_idf(IDF_command_line_argument)
            elif IDF_file_info.suffix().lower() != "idf":
                QMessageBox.warning(self, "Not IDF File", "The " + APPLICATION_NAME + " can only open *.idf files.\n\n" + IDF_command_line_argument)
            elif not IDF_file_info.exists():
                QMessageBox.warning(self, "Nonexistant IDF File", "Tried to open an *.idf file that does not exist.\n\n" + IDF_command_line_argument)
    
    def on_file_menu_new_click(self):
        #check with user if there are unsaved changes before discarding existing IDF
        if self.discard_application_data():
            self.unload_IDF()
            self.load_idf(self.new_IDF_loaded_string)
        
    def on_file_menu_open_click(self):
        #check with user if there are unsaved changes before discarding existing IDF
        if self.discard_application_data():
            file_path, _ = QFileDialog().getOpenFileName(self, "Open File", self.current_session_last_directory_viewed_string, "IDF Files (*.idf);;")
            #QFileDialog default returns file_path = "" when no file is chosen
            if file_path != "":
                self.current_session_last_directory_viewed_string = QFileInfo(file_path).absoluteDir().path()
                self.unload_IDF()
                self.load_idf(file_path)
        
        #used to write out default values from IDF Editor generated *.idf file
        #with open("IDF_object_defaults.idf", "w", encoding="utf-8") as file:
        #    file.write(str(self.IDF_dict))
    
    def change_selected_IDF_path_line_edit(self, text):
        watched_files = self.idf_file_system_watcher.files()
        for watched_file in watched_files:
            self.idf_file_system_watcher.removePath(watched_file)
        
        self.selected_IDF_path_line_edit.setText(text)
        
        if text != "" and text != self.new_IDF_loaded_string:
            self.idf_file_system_watcher.addPath(text)
        
        self.load_displayed_file_tabs()
    
    def save_loaded_IDF_to_file(self, instruction):
        file_path = None
        loaded_IDF_path = self.selected_IDF_path_line_edit.text()
        #no IDF currently loaded to write to a *.idf file
        if loaded_IDF_path == "":
            QMessageBox.warning(
                self,
                "No IDF Loaded",
                "There is no IDF loaded in the " + APPLICATION_NAME + ".\n\nLoad an IDF with File->New or File->Open."
            )
            return
        else:
            #File->Save with a loaded IDF from an existing *.idf file to write to
            if instruction == "File->Save" and loaded_IDF_path != self.new_IDF_loaded_string:
                file_path = loaded_IDF_path
            
            #File->Save for a loaded IDF from File->New
            #or
            #File->Save As
            else:
                file_path, _ = QFileDialog.getSaveFileName(self, "Save File", self.current_session_last_directory_viewed_string, "IDF Files (*.idf);;")
                if file_path == "": #QFileDialog default returns file_path = "" when no file is chosen
                    return
                self.current_session_last_directory_viewed_string = QFileInfo(file_path).absoluteDir().path()
        
        #there is an IDF loaded to be saved to the *.idf file at file_path
        try:
            #make a backup of the *.idf file that will be overwritten, if it exists, in case something goes wrong
            extra_warning_message_text = "Creation of a backup of the *.idf file in the same directory failed prior to the save operation."
            if QFileInfo(file_path).exists():
                shutil.copy2(file_path, file_path + ".backup")
            
            #warning changed if the backup was successful or done at all
            extra_warning_message_text = "Writing to the *.idf failed. A copy of the *.idf was saved as a *.backup file in the same directory prior to the save operation."
            
            with open(file_path, "w") as file:
                file.write("!-Written by " + APPLICATION_NAME + " " + self.BEM_File_editor_version + "\n\n")
                for object_class_name in self.IDF_dict.keys():
                    if len(self.IDF_dict[object_class_name]) > 0:
                        file.write("\n!-   ===========  ALL OBJECTS IN CLASS: " + object_class_name.upper() + "  ===========\n\n")
                        
                        group_name = self.group_name_from_object_class_name(object_class_name)
                        field_IDs = self.field_IDs_dict[object_class_name]
                        field_names = self.field_names_dict[object_class_name]
                        
                        extensible_count, begin_extensible_index = self.extensible_count_and_index(group_name, object_class_name, field_IDs)
                        
                        for individual_object in self.IDF_dict[object_class_name]:
                            
                            #remove consecutive "" fields from the end of the object until the first non-empty field or the begin_extensible_index
                            #otherwise the EnergyPlus engine will complain
                            if extensible_count is not None:
                                field_index = len(individual_object) - 1
                                while individual_object[field_index] == "" and begin_extensible_index <= field_index: 
                                    field_index -= 1
                                individual_object = individual_object[:field_index + 1]
                            
                            file.write(object_class_name + ",\n")
                            for field_index in range(len(individual_object)):
                                comment_text = field_names[field_index]
                                
                                #*.idf is always in SI units
                                if "units" in self.IDD_dict[group_name][object_class_name][field_IDs[field_index]].keys():
                                    comment_text += " [" + self.IDD_dict[group_name][object_class_name][field_IDs[field_index]]["units"][0] + "]"
                                
                                line = "  " + individual_object[field_index]
                                if field_index < len(individual_object) - 1:
                                    line += ", !- " + comment_text + "\n"
                                else:
                                    line += "; !- " + comment_text + "\n\n"
                                file.write(line)
            
            self.change_selected_IDF_path_line_edit(file_path)
            
            #modify undo redo
            self.undo_redo_operation(self.undo_redo_IDF_state_from_drive_string)
            
        except:
            QMessageBox.warning(
                self,
                "Failed to Save File",
                "The file could not be saved.\n" + file_path + "\n\n" + extra_warning_message_text
            )
            #continue so the trace is written to stderr
            raise
    
    def on_file_menu_simulate_IDF_click(self):
        #switch to console tabs
        self.tabs.setCurrentWidget(self.EnergyPlus_console_tab_widget)
        
        if self.EnergyPlus_process is not None:
            QMessageBox.information(self,
                "Simulation in Progress", 
                "There is already a simulation in progress.\n\nWait for the simulation to finish or terminate the simulation.",
            )
        elif self.selected_IDF_path_line_edit.text() == "":
            QMessageBox.information(self,
                "Missing IDF", 
                "There is no IDF loaded to simulate.",
                )
        elif self.selected_EPW_path_line_edit.text() == "":
            QMessageBox.information(self,
                "Missing EPW", 
                "There is no EPW picked to simulate with.",
            )
        else:
            #save file before starting simulation
            self.save_loaded_IDF_to_file("File->Save")
            
            relative_path = None
            if self.os_type == "windows":
                relative_path = "energyplus.exe"
            elif self.os_type == "macos":
                relative_path = "energyplus"
            elif self.os_type == "linux":
                relative_path = ""
            
            executable_path = self.absolute_url_from_EnergyPlus_directory_relative_path(relative_path).toString()
            executable_file_info = QFileInfo(executable_path)
            
            self.EnergyPlus_process = None
            self.EnergyPlus_console_text_edit.clear()
            if executable_file_info.exists():
                self.EnergyPlus_process = QProcess()
                
                self.EnergyPlus_process.readyReadStandardOutput.connect(self.EnergyPlus_process_stdout)
                self.EnergyPlus_process.readyReadStandardError.connect(self.EnergyPlus_process_stderr)
                self.EnergyPlus_process.finished.connect(self.EnergyPlus_process_finished)
                
                IDF_directory_string = QFileInfo(self.selected_IDF_path_line_edit.text()).absoluteDir().path()
                
                #the energyplus.exe creates temporary files in the current working directory
                #the process might not have the permissions to write to the current working directory, so it must be specified explicitly
                #the process should have the permissions to write to the directory where the *.idf file is
                self.EnergyPlus_program_working_directory_path = os.path.join(IDF_directory_string, self.EnergyPlus_program_working_directory_name)
                if os.path.exists(self.EnergyPlus_program_working_directory_path):
                    shutil.rmtree(self.EnergyPlus_program_working_directory_path)
                os.makedirs(self.EnergyPlus_program_working_directory_path)
                self.EnergyPlus_process.setWorkingDirectory(self.EnergyPlus_program_working_directory_path)
                
                self.EnergyPlus_process.startCommand("\"" + executable_path + "\" -w \"" + self.selected_EPW_path_line_edit.text() + "\" -r \"" + self.selected_IDF_path_line_edit.text() + "\" -d \"" + IDF_directory_string + "\"")
            else:
                self.EnergyPlus_console_text_edit.insertPlainText("The " + relative_path + " file could not be run.")
                self.EnergyPlus_console_text_edit.insertPlainText(executable_path)
                self.EnergyPlus_console_text_edit.insertPlainText("")
                self.EnergyPlus_console_text_edit.insertPlainText("This can be from the version of EnergyPlus not being installed or at a custom install location, which can be changed in View->Application Settings.")
    
    def EnergyPlus_process_stdout(self):
        data = self.EnergyPlus_process.readAllStandardOutput()
        stdout = bytes(data).decode("utf8")
        self.EnergyPlus_console_text_edit.insertPlainText(stdout)
        scrollbar = self.EnergyPlus_console_text_edit.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
    
    def EnergyPlus_process_stderr(self):
        data = self.EnergyPlus_process.readAllStandardError()
        stderr = bytes(data).decode("utf8")
        self.EnergyPlus_console_text_edit.setTextColor(self.stderr_text_color)
        self.EnergyPlus_console_text_edit.insertPlainText(stderr)
        scrollbar = self.EnergyPlus_console_text_edit.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
        self.EnergyPlus_console_text_edit.setTextColor(self.stdout_text_color)
    
    def EnergyPlus_process_finished(self):
        self.EnergyPlus_process = None
        
        if os.path.exists(self.EnergyPlus_program_working_directory_path):
            shutil.rmtree(self.EnergyPlus_program_working_directory_path)
        
        self.load_displayed_file_tabs()
    
    def on_terminate_EnergyPlus_simulation_button_clicked(self):
        if self.EnergyPlus_process is None:
            QMessageBox.warning(self, "No Simulation in Progress", "There is no running simulation to terminate.")
        else:
            if self.EnergyPlus_process.state() == QProcess.ProcessState.Running:
                self.EnergyPlus_process.kill()
                self.EnergyPlus_process = None
            else:
                self.EnergyPlus_process = None
            
            self.EnergyPlus_console_text_edit.clear()
            self.EnergyPlus_console_text_edit.setTextColor(self.stderr_text_color)
            self.EnergyPlus_console_text_edit.insertPlainText("User Terminated EnergyPlus Simulation")
            self.EnergyPlus_console_text_edit.setTextColor(self.stdout_text_color)
    
    def on_file_menu_unload_IDF_click(self):
        if self.selected_IDF_path_line_edit.text() == "":
            QMessageBox.information(self, "No IDF Loaded", "There is no IDF loaded in the " + APPLICATION_NAME + " to unload.")
        else:
            #check with user if there are unsaved changes before discarding existing IDF
            if self.discard_application_data():
                self.unload_IDF()
    
    def on_file_menu_unload_EPW_click(self):
        if self.selected_EPW_path_line_edit.text() == "":
            QMessageBox.information(self, "No EPW Loaded", "There is no EPW loaded in the " + APPLICATION_NAME + " to unload.")
        else:
            self.selected_EPW_path_line_edit.setText("")
    
    def undo_redo_remove_IDF_saved_on_drive_index(self):
        for undo_redo_history in [self.undo_history, self.redo_history]:
            for operation_index in range(len(undo_redo_history)):
                if self.undo_redo_IDF_state_from_drive_string in undo_redo_history[operation_index][0]:
                    del undo_redo_history[operation_index]
                    return
        
        #"IDF State on Drive" was not there to remove
        return
    
    def refresh_undo_redo_text_edits(self):
        undo_text_lines = []
        for undo_item in self.undo_history:
            undo_text_lines.append(undo_item[0])
        self.undo_text_edit.setText("\n".join(undo_text_lines))
        scrollbar = self.undo_text_edit.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
        
        redo_text_lines = []
        for redo_item in self.redo_history:
            redo_text_lines.append(redo_item[0])
        self.redo_text_edit.setText("\n".join(redo_text_lines))
    
    def item_undo_redo_string(self, item_undo_redo_string):
        if item_undo_redo_string[9:12] == "New":
            return "New"
        elif item_undo_redo_string[9:14] == "Paste":
            return "Paste"
        elif item_undo_redo_string[9:15] == "Delete":
            return "Delete"
        elif item_undo_redo_string[9:22] == "Field Changed":
            return "Field Changed"
    
    def undo_redo_operation(self, operation, objects_class_name=None, pre_operation_individual_objects=[], post_operation_individual_objects=[], IDF_dict_object_indices=[]):
        if operation == "Undo":
            #there is at least one operation to undo
            if len(self.undo_history) > 0:
                #if "IDF State on Drive" is in the QLabel, that is moved to redo_history
                if self.undo_redo_IDF_state_from_drive_string in self.undo_redo_IDF_status_label.text():
                    self.redo_history.insert(0, [self.undo_redo_IDF_status_label.text()])
                    self.undo_redo_IDF_status_label.setText(self.undo_redo_IDF_unsaved_changes_string)
                
                #move an item that isn't a "IDF State on Drive" from undo_history to redo_history
                item = self.undo_history.pop()
                self.redo_history.insert(0, item)
                
                #undo the operation
                item_undo_redo_string = self.item_undo_redo_string(item[0])
                item_objects_class_name = item[1]
                item_pre_operation_individual_objects = item[2]
                item_post_operation_individual_objects = item[3]
                item_IDF_dict_object_indices = item[4]
                if item_undo_redo_string in ["New", "Paste"]:
                    for object_index in sorted(item_IDF_dict_object_indices, reverse=True):
                        del self.IDF_dict[item_objects_class_name][object_index]
                
                elif item_undo_redo_string == "Delete":
                    item_IDF_dict_object_indices = sorted(item_IDF_dict_object_indices)
                    for element_index in range(len(item_IDF_dict_object_indices)):
                        object_index = item_IDF_dict_object_indices[element_index]
                        self.IDF_dict[item_objects_class_name].insert(object_index, copy.deepcopy(item_pre_operation_individual_objects[element_index]))
                
                elif item_undo_redo_string == "Field Changed":
                    object_index = item_IDF_dict_object_indices[0]
                    self.IDF_dict[item_objects_class_name][object_index] = copy.deepcopy(item_pre_operation_individual_objects[0])
                
                #reapply classes tree filter
                self.filter_class_tree_widget()
                
                #if the most recent item in undo_history is now "IDF State on Drive", move that to the QLabel
                if (len(self.undo_history) > 0 and
                self.undo_redo_IDF_state_from_drive_string in self.undo_history[-1][0] and
                self.undo_redo_IDF_unsaved_changes_string in self.undo_redo_IDF_status_label.text()):
                    self.undo_redo_IDF_status_label.setText(self.undo_history.pop()[0])
                
                self.refresh_undo_redo_text_edits()
        
        elif operation == "Redo":
            #there is at least one operation to redo
            if len(self.redo_history) > 0:
                #if "IDF State on Drive" is in the QLabel, that is moved to undo_history
                if self.undo_redo_IDF_state_from_drive_string in self.undo_redo_IDF_status_label.text():
                    self.undo_history.append([self.undo_redo_IDF_status_label.text()])
                    self.undo_redo_IDF_status_label.setText(self.undo_redo_IDF_unsaved_changes_string)
                
                #move an item that isn't a "IDF State on Drive" from redo_history to undo_history
                item = self.redo_history.pop(0)
                self.undo_history.append(item)
                
                #redo the operation
                item_undo_redo_string = self.item_undo_redo_string(item[0])
                item_objects_class_name = item[1]
                item_pre_operation_individual_objects = item[2]
                item_post_operation_individual_objects = item[3]
                item_IDF_dict_object_indices = item[4]
                if item_undo_redo_string in ["New", "Paste"]:
                    item_IDF_dict_object_indices = sorted(item_IDF_dict_object_indices)
                    for element_index in range(len(item_IDF_dict_object_indices)):
                        object_index = item_IDF_dict_object_indices[element_index]
                        self.IDF_dict[item_objects_class_name].insert(object_index, copy.deepcopy(item_post_operation_individual_objects[element_index]))
                
                elif item_undo_redo_string == "Delete":
                    for object_index in sorted(item_IDF_dict_object_indices, reverse=True):
                        del self.IDF_dict[item_objects_class_name][object_index]
                
                elif item_undo_redo_string == "Field Changed":
                    object_index = item_IDF_dict_object_indices[0]
                    self.IDF_dict[item_objects_class_name][object_index] = copy.deepcopy(item_post_operation_individual_objects[0])
                
                #reapply classes tree filter
                self.filter_class_tree_widget()
                
                #if the most recent item in redo_history is now "IDF State on Drive", move that to the QLabel
                if (len(self.redo_history) > 0 and
                self.undo_redo_IDF_state_from_drive_string in self.redo_history[0][0] and
                self.undo_redo_IDF_unsaved_changes_string in self.undo_redo_IDF_status_label.text()):
                    self.undo_redo_IDF_status_label.setText(self.redo_history.pop(0)[0])
                
                self.refresh_undo_redo_text_edits()
        
        elif operation in ["New", "Field Changed"]:
            self.redo_history = []
            
            #if "IDF State on Drive" is in the QLabel, that is moved to undo_history
            if self.undo_redo_IDF_state_from_drive_string in self.undo_redo_IDF_status_label.text():
                self.undo_history.append([self.undo_redo_IDF_status_label.text()])
                self.undo_redo_IDF_status_label.setText(self.undo_redo_IDF_unsaved_changes_string)
            
            self.undo_history.append([QDateTime.currentDateTime().toString("HH:mm:ss") + " " + operation + " " + objects_class_name, objects_class_name, pre_operation_individual_objects, post_operation_individual_objects, IDF_dict_object_indices])
            
            self.refresh_undo_redo_text_edits()
        
        elif operation in ["Delete", "Paste"]:
            self.redo_history = []
            
            #if "IDF State on Drive" is in the QLabel, that is moved to undo_history
            if self.undo_redo_IDF_state_from_drive_string in self.undo_redo_IDF_status_label.text():
                self.undo_history.append([self.undo_redo_IDF_status_label.text()])
                self.undo_redo_IDF_status_label.setText(self.undo_redo_IDF_unsaved_changes_string)
            
            self.undo_history.append([QDateTime.currentDateTime().toString("HH:mm:ss") + " " + operation + " " + str(len(IDF_dict_object_indices)) + " " + objects_class_name, objects_class_name, pre_operation_individual_objects, post_operation_individual_objects, IDF_dict_object_indices])
            
            self.refresh_undo_redo_text_edits()
        
        elif operation in [self.undo_redo_no_IDF_loaded_string, self.new_IDF_loaded_string, self.undo_redo_IDF_state_from_drive_string, self.undo_redo_IDF_file_changed_externally_string]:
            if operation == self.undo_redo_IDF_state_from_drive_string:
                self.undo_redo_IDF_status_label.setText(QDateTime.currentDateTime().toString("HH:mm:ss") + " " + operation)
            else:
                self.undo_redo_IDF_status_label.setText(operation)
            
            if operation == self.undo_redo_no_IDF_loaded_string:
                self.undo_text_edit.clear()
                self.redo_text_edit.clear()
                self.undo_history = []
                self.redo_history = []
            
            elif operation == self.new_IDF_loaded_string:     
                self.undo_history = []
                self.redo_history = []
            
            elif operation in [self.undo_redo_IDF_state_from_drive_string, self.undo_redo_IDF_file_changed_externally_string]:
                self.undo_redo_remove_IDF_saved_on_drive_index()
    
    def on_units_action_group_triggered(self):
        units_clicked = None
        if self.view_menu_units_top_action.isChecked():
            units_clicked = self.unit_abbreviations[0]
        elif self.view_menu_units_bottom_action.isChecked():
            units_clicked = self.unit_abbreviations[1]
        
        #redo stuff only if the selection changed
        if units_clicked != self.current_session_units_string:
            self.current_session_units_string = units_clicked
            
            #redo Object Info
            object_info_text = self.object_info_text_edit.toPlainText()
            if object_info_text != "":
                #first line contains object class name
                object_class_name = object_info_text.split("\n")[0]
                group_name = self.group_name_from_object_class_name(object_class_name)
                self.populate_object_info_text_edit(group_name, object_class_name)
            
            #reapply classes tree filter
            self.filter_class_tree_widget()
    
    def on_view_menu_hide_empty_classes_triggered(self, checked):
        #block Signals so the Edit->Hide Empty Classes and Show Hide radio buttons don't trigger an additional change signal
        self.show_hide_empty_classes_button_group.blockSignals(True)
        
        if checked:
            self.hide_empty_classes_radio_button.setChecked(True)
        else:
            self.show_empty_classes_radio_button.setChecked(True)
        
        #allow Signals again
        self.show_hide_empty_classes_button_group.blockSignals(False)
        
        self.filter_class_tree_widget()
    
    def load_idf(self, IDF_path_string):
        self.selected_EnergyPlus_version_combo_box.setEnabled(False)
        self.change_selected_IDF_path_line_edit(IDF_path_string)
        
        self.undo_history = []
        if IDF_path_string == self.new_IDF_loaded_string:
            self.undo_redo_operation(self.new_IDF_loaded_string)
        else:
            self.undo_redo_operation(self.undo_redo_IDF_state_from_drive_string)
        self.redo_history = []
        
        self.top_objects_table_widget_new_button.setEnabled(True)
        self.top_objects_table_widget_delete_button.setEnabled(True)
        self.top_objects_table_widget_copy_button.setEnabled(True)
        self.top_objects_table_widget_paste_button.setEnabled(True)
        
        self.bottom_objects_table_widget_new_button.setEnabled(True)
        self.bottom_objects_table_widget_delete_button.setEnabled(True)
        self.bottom_objects_table_widget_copy_button.setEnabled(True)
        self.bottom_objects_table_widget_paste_button.setEnabled(True)
        
        self.load_IDD()
        self.IDF_dict = {}
        for group_name in self.IDD_dict.keys():
            for object_class_name in self.IDD_dict[group_name].keys():
                self.IDF_dict[object_class_name] = []
        
        #File->Open parse IDF file into self.IDF_dict, rather than a blank File->New
        if IDF_path_string != self.new_IDF_loaded_string:
            try:
                with open(IDF_path_string, "r") as IDF_file:
                    IDF_lines = IDF_file.readlines()
            except:
                QMessageBox.critical(
                    self,
                    "Failed to Read *.idf File",
                    "An exception occurred while trying to read the of contents the *.idf file.\n" + IDF_path_string + ";\n\nAborting operation."
                )
                self.unload_IDF()
                #continue so the trace is written to stderr
                raise
                return
            
            #remove all !comments, trailing and leading white space
            for line_index in range(len(IDF_lines)):
                IDF_lines[line_index] = IDF_lines[line_index].split("!")[0].strip()
            
            #remove all empty lines
            IDF_lines = [line for line in IDF_lines if len(line) > 0]
            
            #combine into one string
            IDF_string = "".join(IDF_lines)
            
            #split into objects and remove "" at the end
            IDF_object_strings = IDF_string.split(";")[:-1]
            
            try:
                for IDF_object_string in IDF_object_strings:
                    IDF_object_list = IDF_object_string.split(",")
                    #remove leading and trailing white space
                    IDF_object_list = [field.strip() for field in IDF_object_list]
                    object_class_name = IDF_object_list[0]
                    object_fields = IDF_object_list[1:]
                    
                    #check if the Version object Version Identifier field matches the version the BEM File Editor is using
                    if object_class_name == "Version":
                        IDF_version = object_fields[0]
                        selected_EnergyPlus_version = self.selected_EnergyPlus_version_combo_box.currentText()[-4:]
                        if IDF_version != selected_EnergyPlus_version:
                            QMessageBox.warning(self, "Mismatched EnergyPlus Version", "Tried to read an *.idf file with a Version object Version Identifier field of \"" + IDF_version + "\" as an EnergyPlus " + selected_EnergyPlus_version + " file. Continuing to read the *.idf file.\n\nTo prevent this warning, populate the Version object with the correct value or delete the Version object.")
                    
                    #check if *.idf file is malformed
                    group_name = self.group_name_from_object_class_name(object_class_name)
                    if group_name is None:
                        QMessageBox.critical(self, "Malformed *.idf File", "Tried to read an object with an invalid object class name.\n" + IDF_object_string + ";\n\nAborting operation.")
                        self.unload_IDF()
                        return
                    else:
                        field_IDs = self.field_IDs_dict[object_class_name]
                        if len(object_fields) > len(field_IDs):
                            QMessageBox.critical(self, "Malformed *.idf File", "Tried to read an object with more fields than the object class definition.\n" + IDF_object_string + ";\n\nAborting operation.")
                            self.unload_IDF()
                            return
                        
                        for field_index in range(len(object_fields)):
                            ID = field_IDs[field_index]
                            if "type" in self.IDD_dict[group_name][object_class_name][ID].keys() and "choice" == self.IDD_dict[group_name][object_class_name][ID]["type"][0]:
                                if object_fields[field_index] not in self.IDD_dict[group_name][object_class_name][ID]["key"] and object_fields[field_index] != "":
                                    #annoying case where the capitalization is different
                                    lowercase_choices = [text.lower() for text in self.IDD_dict[group_name][object_class_name][ID]["key"]]
                                    if object_fields[field_index].lower() in lowercase_choices:
                                        index_of_case_insensitive_match = lowercase_choices.index(object_fields[field_index].lower())
                                        object_fields[field_index] = self.IDD_dict[group_name][object_class_name][ID]["key"][index_of_case_insensitive_match]
                                    else:
                                        QMessageBox.critical(self, "Malformed *.idf File", "Tried to read an object with a field value not one of the available choices.\n" + IDF_object_string + ";\n\nAborting operation.")
                                        self.unload_IDF()
                                        return
                    
                    self.IDF_dict[object_class_name].append(object_fields)
            except:
                QMessageBox.critical(
                    self,
                    "Failed to Parse *.idf File",
                    "An exception occurred while trying to parse an object in the *.idf file.\n" + IDF_object_string + ";\n\nAborting operation."
                )
                self.unload_IDF()
                #continue so the trace is written to stderr
                raise
                return
        
        self.populate_classes_tree_widget()
    
    def unload_IDF(self):
        self.IDF_dict = {}
        self.selected_EnergyPlus_version_combo_box.setEnabled(True)
        self.change_selected_IDF_path_line_edit("")
        
        self.filter_classes_line_edit.clear()
        self.view_menu_hide_empty_classes_action.setChecked(False) #also changes radio button
        self.show_empty_classes_radio_button.setChecked(True)
        
        self.filter_objects_line_edit.clear()
        self.filter_objects_case_sensitive_check_box.setChecked(False)
        self.filter_objects_match_entire_field_text_check_box.setChecked(False)
        
        self.classes_tree_widget.clear()
        self.object_info_text_edit.clear()
        
        self.undo_redo_operation(self.undo_redo_no_IDF_loaded_string)
        
        self.top_objects_table_widget.setRowCount(0)
        self.top_objects_table_widget_new_button.setEnabled(False)
        self.top_objects_table_widget_delete_button.setEnabled(False)
        self.top_objects_table_widget_copy_button.setEnabled(False)
        self.top_objects_table_widget_paste_button.setEnabled(False)

        self.bottom_objects_table_widget.setRowCount(0)
        self.bottom_objects_table_widget_new_button.setEnabled(False)
        self.bottom_objects_table_widget_delete_button.setEnabled(False)
        self.bottom_objects_table_widget_copy_button.setEnabled(False)
        self.bottom_objects_table_widget_paste_button.setEnabled(False)
    
    def show_python_console_tab(self):
        if self.current_session_show_python_console_tab_bool and self.tabs.indexOf(self.python_console_widget) == -1:
            self.tabs.insertTab(0, self.python_console_widget, "python console")
        elif not self.current_session_show_python_console_tab_bool and self.tabs.indexOf(self.python_console_widget) != -1:
            self.tabs.removeTab(self.tabs.indexOf(self.python_console_widget))
    
    def opened_idf_file_changed_externally(self, path):
        current_datetime = QDateTime.currentDateTime()
        last_modified_datetime = QFileInfo(path).lastModified()
        milliseconds_difference = current_datetime.msecsTo(last_modified_datetime)
        
        #the timing of the os noticing a changed file and the *.idf being saved can trigger multiple unintended Signals
        #only warn the user if the time difference between the *.idf file modification date and now is greater than 100ms
        #short 100ms window where the *.idf file is externally changed and the user isn't warned
        # if abs(milliseconds_difference) > 100:
            # QMessageBox.warning(
                    # self,
                    # "IDF Changed",
                    # "The opened *.idf file was modified by something other than the " + APPLICATION_NAME + "."
                # )
        
            # #modify undo redo
            # self.undo_redo_operation(self.undo_redo_IDF_file_changed_externally_string)
        
        #to do
        #QFileSystemWatcher is stopped working and now isn't noticing any changes to the watched file
        #it was working 21 Apr so I do not know why
        #commenting out for now
    
    def on_pick_EPW_file_click(self):
        file_path, _ = QFileDialog().getOpenFileName(self, "Open File", self.current_session_last_directory_viewed_string, "EPW Files (*.epw);;")
        if file_path != "": #QFileDialog default returns file_path = "" when no file is chosen
            self.current_session_last_directory_viewed_string = QFileInfo(file_path).absoluteDir().path()
            self.selected_EPW_path_line_edit.setText(file_path)
    
    def on_python_console_refresh_button_clicked(self):
        self.python_console_text_edit.clear()
        try:
            with open(PYTHON_CONSOLE_FILEPATH, "r") as python_console_stderr_file:
                file_content = python_console_stderr_file.read()
                self.python_console_text_edit.setPlainText(file_content)
                scrollbar = self.python_console_text_edit.verticalScrollBar()
                scrollbar.setValue(scrollbar.maximum())
        except:
            QMessageBox.warning(
                self,
                "Failed to Open File Log File",
                "The log file failed to be read."
            )
            #continue so the trace is written to stderr
            raise
    
    def on_show_hide_empty_classes_button_group_toggled(self, radio_button, checked):
        if checked:
            #block Signals so the Edit->Hide Empty Classes and Show Hide radio buttons don't trigger an additional change signal
            self.view_menu_hide_empty_classes_action.blockSignals(True)
            
            if radio_button.text() == "Show":
                self.view_menu_hide_empty_classes_action.setChecked(False)
            else:
                self.view_menu_hide_empty_classes_action.setChecked(True)
            
            #allow Signals again
            self.view_menu_hide_empty_classes_action.blockSignals(False)
            
            self.filter_class_tree_widget()
    
    def filter_class_tree_widget(self):
        #an IDF is loaded so there is a classes QTreeWidget to filter rows of
        if self.selected_IDF_path_line_edit.text() != "":
            classes_filter_text = self.filter_classes_line_edit.text()
            hide_empty_classes = self.view_menu_hide_empty_classes_action.isChecked()
            
            object_field_filter_text = self.filter_objects_line_edit.text()
            object_field_filter_case_sensitive = self.filter_objects_case_sensitive_check_box.isChecked()
            object_field_filter_match_entire_field_text = self.filter_objects_match_entire_field_text_check_box.isChecked()
            
            top_objects_table_class_name = None
            if self.top_radio_button_group.checkedButton() is not None:
                top_objects_table_class_name = self.top_radio_button_group.checkedButton().objectName()
            bottom_objects_table_class_name = None
            if self.bottom_radio_button_group.checkedButton() is not None:
                bottom_objects_table_class_name = self.bottom_radio_button_group.checkedButton().objectName()
            
            for object_class_name in self.object_class_rows_dict.keys():
                self.hidden_object_indices[object_class_name] = []
                
                for object_index in range(len(self.IDF_dict[object_class_name])):
                    individual_object = self.IDF_dict[object_class_name][object_index]
                    hide_object = True
                    if object_field_filter_text != "":
                        for field_text in individual_object:
                            if ( (object_field_filter_case_sensitive and object_field_filter_match_entire_field_text and object_field_filter_text == field_text) or
                            (object_field_filter_case_sensitive and not object_field_filter_match_entire_field_text and object_field_filter_text in field_text) or 
                            (not object_field_filter_case_sensitive and object_field_filter_match_entire_field_text and object_field_filter_text.lower() == field_text.lower()) or 
                            (not object_field_filter_case_sensitive and not object_field_filter_match_entire_field_text and object_field_filter_text.lower() in field_text.lower()) ):
                                #there is at least once matching object field satisfying the conditions
                                hide_object = False
                                break
                        
                        if hide_object:
                            self.hidden_object_indices[object_class_name].append(object_index)
                
                #change object class count in classes tree count column
                show_objects_count = self.set_object_count(object_class_name)
                
                #keep in mind the empty string "" is in every string
                if classes_filter_text.lower() not in object_class_name.lower() or (hide_empty_classes and show_objects_count == 0):
                    self.object_class_rows_dict[object_class_name].setHidden(True)
                else:
                    self.object_class_rows_dict[object_class_name].setHidden(False)
                
                #repopulate object table in case the list of hidden objects changed for that object_class_name
                if top_objects_table_class_name is not None and top_objects_table_class_name == object_class_name:
                    self.populate_objects_table_widget(self.top_objects_table_widget, object_class_name)
                if bottom_objects_table_class_name is not None and bottom_objects_table_class_name == object_class_name:
                    self.populate_objects_table_widget(self.bottom_objects_table_widget, object_class_name)
            
            #hide group row if all child rows are hidden
            if classes_filter_text == "" and not hide_empty_classes:
                for group_name in self.group_rows_dict.keys():
                    self.group_rows_dict[group_name].setHidden(False)
            else:
                for group_name in self.group_rows_dict.keys():
                    all_group_object_class_rows_hidden = True
                    for object_class_name in self.IDD_dict[group_name].keys():
                        if not self.object_class_rows_dict[object_class_name].isHidden():
                            all_group_object_class_rows_hidden = False
                            break
                    self.group_rows_dict[group_name].setHidden(all_group_object_class_rows_hidden)
    
    def closeEvent(self, event: QCloseEvent):
        #check with user if there are unsaved changes before closing
        if self.discard_application_data():
            #write current session values to settings_dict
            self.settings_dict["selected_EnergyPlus_version_string"] = self.selected_EnergyPlus_version_combo_box.currentText()
            self.settings_dict["last_directory_viewed_string"] = self.current_session_last_directory_viewed_string
            self.settings_dict["units_string"] = self.current_session_units_string
            self.settings_dict["disable_update_prompt_bool"] = self.current_session_disable_update_prompt_bool
            self.settings_dict["show_python_console_tab_bool"] = self.current_session_show_python_console_tab_bool
            self.settings_dict["font_point_size_int"] = self.current_session_font_point_size_int
            self.settings_dict["editor_splitter_int_list"] = self.editor_splitter.sizes()
            self.settings_dict["editor_top_splitter_int_list"] = self.editor_top_splitter.sizes()
            for column_index in range(len(self.classes_tree_widget_headers_list)):
                self.settings_dict["classes_tree_widget_column_widths_int_list"][column_index] = self.classes_tree_widget.columnWidth(column_index)
            for EnergyPlus_version_string in self.all_suported_EnergyPlus_versions:
                self.settings_dict["EnergyPlus_installation_directories_dict"][EnergyPlus_version_string] = self.current_session_EnergyPlus_installation_directories_dict[EnergyPlus_version_string]
            self.settings_dict["displayed_files_as_text_list"] = self.current_session_displayed_files_as_text_list
            self.settings_dict["displayed_files_as_CSV_list"] = self.current_session_displayed_files_as_CSV_list
            self.settings_dict["displayed_files_as_HTML_list"] = self.current_session_displayed_files_as_HTML_list
            
            #write settings_dict to QSettings file
            for key in self.settings_dict.keys():
                self.settings.setValue(key, self.settings_dict[key])
            
            #close all windows if main window is closed
            self.geometry_viewer_window = None
            self.geometry_selector_window = None
            self.graph_window = None
            
            #the event does not propagate and the application is closed
            event.accept()
        
        #the user wants a chance to save changes
        else:
            #the event does not propagate and no changes occur
            event.ignore()
    
    def discard_application_data(self):
        #warn the user if there are unsaved changes
        if not (self.undo_redo_no_IDF_loaded_string in self.undo_redo_IDF_status_label.text() or self.undo_redo_IDF_state_from_drive_string in self.undo_redo_IDF_status_label.text()):
            #prompt the user to confirm closing the application or not
            reply = QMessageBox.question(
                self,
                "Unsaved Work",
                "You have unsaved work in the " + APPLICATION_NAME + ".\n\nContinue the current operation?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Cancel
            )
            
            #user decided to discard unsaved changes
            if reply == QMessageBox.StandardButton.Yes:
                return True
            #user decided to cancel the close operation because of unsaved changes
            else:
                return False
        #no unsaved changes
        else:
            return True
    
    
    #for checking for new BEM File Editor version
    def on_finished(self):
        if self.reply:
            self.reply.deleteLater()
    
    #for checking for new BEM File Editor version
    def on_ready_read(self):
        if self.reply:
            if self.reply.error() == QNetworkReply.NetworkError.NoError:
                #WARNING: data in reply is deleted after reading
                self.available_BEM_File_Editor_version = self.reply.readAll().data().decode("utf-8")
                if not self.current_session_disable_update_prompt_bool:
                    available_version_split = self.available_BEM_File_Editor_version.split(".")
                    available_version_tuple = (int(available_version_split[0]),int(available_version_split[1]),int(available_version_split[2]))
                    current_version_split = self.BEM_File_editor_version.split(".")
                    current_version_tuple = (int(current_version_split[0]),int(current_version_split[1]),int(current_version_split[2]))
                    
                    if current_version_tuple < available_version_tuple:
                        self.open_popup_window("Available Version")
    
    #for checking for new BEM File Editor version
    def on_error(self, code: QNetworkReply.NetworkError):
        if self.reply:
            self.available_BEM_File_Editor_version = "Available Version Internet Query Failed"
            #QMessageBox.warning(self, "Error Occurred", self.reply.errorString())
            if not self.current_session_disable_update_prompt_bool:
                QMessageBox.warning(self, "Version Internet Query Failed", "Failed to query the most recent version of the " + APPLICATION_NAME + " from the internet.\n\nYou can disable this warning with View->Application Settings Disable Update Prompt.")
    
    def open_popup_window(self, window_type, options_list=None, item=None):
        if window_type == "Available Version":
            self.popup_window = AvailableVersionDialog(self)
        elif window_type == "Application Settings":
            self.popup_window = ApplicationSettingsDialog(self)
        elif window_type == "Field Choices":
            self.popup_window = FieldChoicesDialog(self, options_list, item)
            self.popup_window.setMinimumSize(self.screen_width / 3, self.screen_height / 3)
        elif window_type == "Undo Review Preview":
            self.popup_window = UndoRedoPreviewDialog(self)
            self.popup_window.setMinimumSize(self.screen_width / 2, self.screen_height / 2)
        
        self.popup_window.exec()
    
    def open_EnergyPlus_PDF(self, relative_path):
        PDF_url = self.absolute_url_from_EnergyPlus_directory_relative_path(relative_path)
        QDesktopServices.openUrl(PDF_url)
    
    def absolute_url_from_EnergyPlus_directory_relative_path(self, relative_path):
        EnergyPlus_version_string = self.selected_EnergyPlus_version_combo_box.currentText()
        EnergyPlus_version_installation_directory = self.current_session_EnergyPlus_installation_directories_dict[EnergyPlus_version_string]
        
        base_url = QUrl(EnergyPlus_version_installation_directory)
        joined_url = base_url.resolved(relative_path)
        return joined_url
    
    def load_IDD(self):
        #only refresh self.IDD_dict and self.IDF_defaults_dict if the EnergyPlus version is different
        if self.IDD_dict == {} or self.IDD_dict["Simulation Parameters"]["Version"]["A1"]["default"][0] not in self.selected_EnergyPlus_version_combo_box.currentText():
            self.IDD_dict = IDD_dictionaries.pick_IDD(self.selected_EnergyPlus_version_combo_box.currentText())
            self.IDF_defaults_dict = IDF_object_defaults_dictionaries.pick_IDF_objects_defaults(self.selected_EnergyPlus_version_combo_box.currentText())
        
            self.hidden_object_indices = {}
            self.field_IDs_dict = {}
            self.field_names_dict = {}
            self.references_object_fields_dict = {}
            self.node_object_fields_list = []
            self.reference_class_name_dict = {}
            for group_name in self.IDD_dict.keys():
                for object_class_name in self.IDD_dict[group_name].keys():
                    #used for filtering
                    self.hidden_object_indices[object_class_name] = []
                    
                    field_IDs = []
                    field_names = []
                    for key in self.IDD_dict[group_name][object_class_name].keys():
                        if key[0] in ["A","N"] and key[1].isdigit():
                            field_IDs.append(key)
                            
                            ID = key
                            if "field" in self.IDD_dict[group_name][object_class_name][ID].keys():
                                field_names.append(self.IDD_dict[group_name][object_class_name][ID]["field"][0])
                            else:
                                field_names.append(ID)
                    self.field_IDs_dict[object_class_name] = field_IDs
                    self.field_names_dict[object_class_name] = field_names
                    
                    for field_index in range(len(field_IDs)):
                        ID = field_IDs[field_index]
                        #dictionary of lists with (key,value) as (reference,list of [object class name,field_index])
                        if "reference" in self.IDD_dict[group_name][object_class_name][ID].keys():
                            for reference in self.IDD_dict[group_name][object_class_name][ID]["reference"]:
                                #add the key if the key doesn't exist
                                if reference not in self.references_object_fields_dict.keys():
                                    self.references_object_fields_dict[reference] = []
                                self.references_object_fields_dict[reference].append([object_class_name,field_index])
                        
                        #list of [object class name,field_index] pairs with \type node
                        if "type" in self.IDD_dict[group_name][object_class_name][ID].keys() and "node" == self.IDD_dict[group_name][object_class_name][ID]["type"][0]:
                            self.node_object_fields_list.append([object_class_name,field_index])
                        
                        #dictionary of lists with (key,value) as (reference-class-name,list of object classes)
                        if "reference-class-name" in self.IDD_dict[group_name][object_class_name][ID].keys():
                            for reference_class_name in self.IDD_dict[group_name][object_class_name][ID]["reference-class-name"]:
                                #add the key if the key doesn't exist
                                if reference_class_name not in self.reference_class_name_dict.keys():
                                    self.reference_class_name_dict[reference_class_name] = []
                                #add the object_class_name if not already in the list
                                if object_class_name not in self.reference_class_name_dict[reference_class_name]:
                                    self.reference_class_name_dict[reference_class_name].append(object_class_name)
    
    def populate_classes_tree_widget(self):
        self.top_radio_button_group = QButtonGroup()
        self.top_radio_button_group.buttonToggled.connect(self.on_top_radio_button_group_toggled)
        self.bottom_radio_button_group = QButtonGroup()
        self.bottom_radio_button_group.buttonToggled.connect(self.on_bottom_radio_button_group_toggled)
        self.group_rows_dict = {}
        self.object_class_rows_dict = {}
        top_radio_button_selected = False
        bottom_radio_button_selected = False
        for group_name in self.IDD_dict.keys():
            group_row = QTreeWidgetItem(self.classes_tree_widget)
            self.group_rows_dict[group_name] = group_row
            group_row.setText(0, group_name)
            for object_class_name in self.IDD_dict[group_name].keys():
                object_class_row = QTreeWidgetItem(group_row)
                self.object_class_rows_dict[object_class_name] = object_class_row
                object_class_row.setText(0, object_class_name)
                group_row.addChild(object_class_row)
                
                top_radio_button = QRadioButton(" ") #space prevents left side of circle being cut off
                top_radio_button.setObjectName(object_class_name)
                self.top_radio_button_group.addButton(top_radio_button)
                top_radio_button_cell_layout = QHBoxLayout()
                top_radio_button_cell_layout.setContentsMargins(0,0,0,0)
                top_radio_button_cell_layout.addWidget(top_radio_button,alignment=Qt.AlignHCenter)
                top_radio_button_cell_widget = QWidget()
                top_radio_button_cell_widget.setLayout(top_radio_button_cell_layout)
                self.classes_tree_widget.setItemWidget(object_class_row, 1, top_radio_button_cell_widget)
                
                bottom_radio_button = QRadioButton(" ") #space prevents left side of circle being cut off
                bottom_radio_button.setObjectName(object_class_name)
                self.bottom_radio_button_group.addButton(bottom_radio_button)
                bottom_radio_button_cell_layout = QHBoxLayout()
                bottom_radio_button_cell_layout.setContentsMargins(0,0,0,0)
                bottom_radio_button_cell_layout.addWidget(bottom_radio_button,alignment=Qt.AlignHCenter)
                bottom_radio_button_cell_widget = QWidget()
                bottom_radio_button_cell_widget.setLayout(bottom_radio_button_cell_layout)
                self.classes_tree_widget.setItemWidget(object_class_row, 2, bottom_radio_button_cell_widget)
                
                objects_count = self.set_object_count(object_class_name)
                
                #show the first nonempty class in the top table and the second nonempty class in the bottom table
                if objects_count != 0:
                    if not top_radio_button_selected:
                        top_radio_button.setChecked(True)
                        top_radio_button_selected = True
                    elif not bottom_radio_button_selected:
                        bottom_radio_button.setChecked(True)
                        bottom_radio_button_selected = True
        
        #if the IDF is almost empty, then the top radio button will default to Version and the bottom radio button will default to Building
        if not top_radio_button_selected:
            for radio_button in self.top_radio_button_group.buttons():
                if radio_button.objectName() == "Version":
                    radio_button.setChecked(True)
                    break
        if not bottom_radio_button_selected:
            for radio_button in self.bottom_radio_button_group.buttons():
                if radio_button.objectName() == "Building":
                    radio_button.setChecked(True)
                    break
        
        self.classes_tree_widget.expandAll()
    
    def set_object_count(self, object_class_name):
        show_objects_count = len(self.IDF_dict[object_class_name]) - len(self.hidden_object_indices[object_class_name])
        if show_objects_count == 0:
            self.object_class_rows_dict[object_class_name].setText(3, "")
        else:
            self.object_class_rows_dict[object_class_name].setText(3, str(show_objects_count).zfill(4))
        
        return show_objects_count
    
    def on_classes_tree_widget_item_clicked(self, item, column):
        #clicked a group name or something other than an object class row
        if item.parent() is not None:
            group_name = item.parent().text(0)
            object_class_name = item.text(0)
            self.populate_object_info_text_edit(group_name, object_class_name)
    
    def on_top_radio_button_group_toggled(self, top_radio_button, checked):
        #find matching button in other column to enable/disable
        for radio_button in self.bottom_radio_button_group.buttons():
            if radio_button.objectName() == top_radio_button.objectName():
                bottom_radio_button = radio_button
        self.on_radio_button_group_toggled(top_radio_button, bottom_radio_button, checked, self.top_objects_table_widget)
        
    def on_bottom_radio_button_group_toggled(self, bottom_radio_button, checked):
        #find matching button in other column to enable/disable
        for radio_button in self.top_radio_button_group.buttons():
            if radio_button.objectName() == bottom_radio_button.objectName():
                top_radio_button = radio_button
        self.on_radio_button_group_toggled(bottom_radio_button, top_radio_button, checked, self.bottom_objects_table_widget)
    
    def on_radio_button_group_toggled(self, button, paired_button, checked, objects_table_widget):
        #this radio button was clicked on and changed state
        if checked:
            object_class_name = button.objectName()
            self.populate_objects_table_widget(objects_table_widget, object_class_name)
        #flip the paired button's enabled/disabled state
        paired_button.setEnabled(not paired_button.isEnabled())
    
    def field_displayed_units(self, group_name, object_class_name, ID):
        if "units" in self.IDD_dict[group_name][object_class_name][ID].keys():
            displayed_si_units = self.IDD_dict[group_name][object_class_name][ID]["units"][0]
            
            if self.current_session_units_string == "SI":
                return displayed_si_units
            elif self.current_session_units_string == "IP":
                units_key = displayed_si_units + "_"

                if "ip-units" in self.IDD_dict[group_name][object_class_name][ID].keys():
                    ip_units_string = self.IDD_dict[group_name][object_class_name][ID]["ip-units"][0]
                    units_key += ip_units_string
            
                displayed_ip_units, _, _ = self.unit_conversions_dict[units_key]
                return displayed_ip_units
        
        elif "unitsBasedOnField" in self.IDD_dict[group_name][object_class_name][ID].keys():
            return "varies"
        
        else:
            return None
    
    def unit_conversion(self, group_name, object_class_name, ID):
        displayed_si_units = None
        displayed_ip_units = None
        field_multiplier = None
        field_adder = None
        
        units_key = None
        if "units" in self.IDD_dict[group_name][object_class_name][ID].keys():
            displayed_si_units = self.IDD_dict[group_name][object_class_name][ID]["units"][0]
            units_key = displayed_si_units + "_"
            
            if "ip-units" in self.IDD_dict[group_name][object_class_name][ID].keys():
                ip_units_string = self.IDD_dict[group_name][object_class_name][ID]["ip-units"][0]
                units_key += ip_units_string
                
            _, field_multiplier, field_adder = self.unit_conversions_dict[units_key]
        
        elif "unitsBasedOnField" in self.IDD_dict[group_name][object_class_name][ID].keys():
            displayed_si_units = "varies"
            displayed_ip_units = displayed_si_units
        
        return displayed_si_units, displayed_ip_units, field_multiplier, field_adder
    
    def extensible_count_and_index(self, group_name, object_class_name, field_IDs):
        extensible_count = None
        begin_extensible_index = None
        if "extensible" in self.IDD_dict[group_name][object_class_name].keys():
            extensible_count = int(self.IDD_dict[group_name][object_class_name]["extensible"][0])
            for field_index in range(len(field_IDs)):
                ID = field_IDs[field_index]
                if "begin-extensible" in self.IDD_dict[group_name][object_class_name][ID].keys():
                    begin_extensible_index = field_index
                    break
        
        return extensible_count, begin_extensible_index
    
    def string_is_alphanumeric_int_float(self, text):
        #could have 2 of "+" or 2 of "-" from scientific notation, like "+.4e+2"
        if len(text) > 0 and all(character in ["0","1","2","3","4","5","6","7","8","9",".","+","-","e","E"] for character in text) and text.count(".") <= 1 and text.count("+") <= 2 and text.count("-") <= 2 and text.count("e") + text.count("E") <= 1: #could be int, float, text in scientific notation, or non-numeric string
            if text.count("e") + text.count("E") == 1: #could be text in scientific notation or non-numeric string
                mantissa, exponent = text.lower().split("e")
                mantissa = self.string_is_alphanumeric_int_float(mantissa)
                exponent = self.string_is_alphanumeric_int_float(exponent)
                if (type(mantissa) is int or type(mantissa) is float) and type(exponent) is int: #must be text in scientific notation
                    #convert to float, but could still be an int
                    output_representation = float(text)
                    if output_representation.is_integer():
                        output_representation = int(output_representation)
                else: #must be non-numeric string
                    output_representation = text
            else: #could be int, float, or non-numeric string
                if text.count("+") + text.count("-") == 0 or (text.count("+") + text.count("-") == 1 and (text[0] == "+" or text[0] == "-")): #must be int or float
                    #convert to float, but could still be an int
                    output_representation = float(text)
                    if output_representation.is_integer():
                        output_representation = int(output_representation)
                else: #must be non-numeric string
                    output_representation = text
        else: #must be non-numeric string
            output_representation = text
        
        return output_representation
    
    def populate_objects_table_widget(self, objects_table_widget, object_class_name):
        #block Signals, like cellChanged, while table is being populated
        objects_table_widget.blockSignals(True)
        
        group_name = self.group_name_from_object_class_name(object_class_name)
        field_IDs = self.field_IDs_dict[object_class_name]
        field_names = self.field_names_dict[object_class_name]
        
        #add vertical header
        objects_table_widget.clear()
        objects_table_widget.setRowCount(len(field_IDs) + 1)
        header_strings = [""] * (len(field_IDs) + 1)
        header_strings[0] = "Field [Units]"
        for field_index in range(len(field_IDs)):
            ID = field_IDs[field_index]
            field_vertical_header = field_names[field_index]
            
            displayed_units = self.field_displayed_units(group_name, object_class_name, ID)
            if displayed_units is not None:
                field_vertical_header += " [" + displayed_units + "]"
            
            header_strings[field_index + 1] = field_vertical_header
        objects_table_widget.setVerticalHeaderLabels(header_strings)
        #add objects
        objects_table_widget.setColumnCount(len(self.IDF_dict[object_class_name]))
        for object_index in range(len(self.IDF_dict[object_class_name])):
            item = QTableWidgetItem("Object " + str(object_index + 1))
            item.setFlags(item.flags() & ~Qt.ItemIsEditable)
            objects_table_widget.setItem(0, object_index, item)
            
            individual_object = self.IDF_dict[object_class_name][object_index]
            for field_index in range(min(len(field_IDs), len(individual_object))):
                ID = field_IDs[field_index]
                
                #combo box
                if "type" in self.IDD_dict[group_name][object_class_name][ID].keys() and "choice" == self.IDD_dict[group_name][object_class_name][ID]["type"][0]:
                    combo_box = CustomComboBox()
                    combo_box.addItems([""] + self.IDD_dict[group_name][object_class_name][ID]["key"])
                    combo_box.setCurrentText(individual_object[field_index])
                    combo_box.currentTextChanged.connect(lambda text, object_class_name=object_class_name, object_index=object_index, field_index=field_index: self.IDF_object_combo_box_field_changed(text, object_class_name, object_index, field_index))
                    
                    objects_table_widget.setCellWidget(field_index + 1, object_index, combo_box)
                
                #table cell with text
                else:
                    field_text = individual_object[field_index]
                    if self.current_session_units_string == "SI":
                        objects_table_widget.setItem(field_index + 1, object_index, QTableWidgetItem(field_text))
                    
                    elif self.current_session_units_string == "IP":
                        displayed_si_units, displayed_ip_units, field_multiplier, field_adder = self.unit_conversion(group_name, object_class_name, ID)
                        
                        if field_multiplier is None or field_adder is None: #special case for hh:mm unit
                            objects_table_widget.setItem(field_index + 1, object_index, QTableWidgetItem(field_text))
                        else:
                            output_representation = self.string_is_alphanumeric_int_float(field_text)
                            if type(output_representation) is int or type(output_representation) is float:
                                    table_cell_text = str(output_representation * field_multiplier + field_adder)
                                    objects_table_widget.setItem(field_index + 1, object_index, QTableWidgetItem(table_cell_text))
                            elif type(output_representation) is str:
                                #not an int or a float so write to the table whether it's valid or invalid for the field
                                objects_table_widget.setItem(field_index + 1, object_index, QTableWidgetItem(field_text))
                    
                    #changes cell color to signify invalid field contents
                    self.apply_table_cell_validity_color(object_class_name, objects_table_widget, field_index + 1, object_index)
        
        #hide hidden object columns
        for object_index in range(len(self.IDF_dict[object_class_name])):
            objects_table_widget.setColumnHidden(object_index, object_index in self.hidden_object_indices[object_class_name])
        
        objects_table_widget.resizeColumnsToContents()
        
        #allow Signals again
        objects_table_widget.blockSignals(False)
    
    def group_name_from_object_class_name(self, object_class_name):
        for group_name in self.IDD_dict.keys():
            if object_class_name in self.IDD_dict[group_name].keys():
                return group_name
        
        #object_class_name is invalid
        return None
    
    def field_choices(self, references):
        valid_choices = []
        for reference in references:
            if reference in self.references_object_fields_dict.keys():
                for object_class_name, field_index in self.references_object_fields_dict[reference]:
                    for object_list in self.IDF_dict[object_class_name]:
                        if field_index < len(object_list) and object_list[field_index] != "":
                            valid_choices.append(object_list[field_index])
            elif reference in self.reference_class_name_dict.keys():
                valid_choices += self.reference_class_name_dict[reference]
        
        return valid_choices
    
    def on_table_object_button_clicked(self, top_or_bottom, button_name):
        button_group = None
        objects_table_widget = None
        if top_or_bottom == "Top":
            button_group = self.top_radio_button_group
            objects_table_widget = self.top_objects_table_widget
        elif top_or_bottom == "Bottom":
            button_group = self.bottom_radio_button_group
            objects_table_widget = self.bottom_objects_table_widget
        
        if button_group.checkedButton() is not None:
            object_class_name = button_group.checkedButton().objectName()
            
            if button_name == "New":
                new_object_for_IDF_dict = copy.deepcopy(self.IDF_defaults_dict[object_class_name][0])
                self.IDF_dict[object_class_name].append(copy.deepcopy(new_object_for_IDF_dict))
                new_object_for_undo_redo_history = copy.deepcopy(self.IDF_defaults_dict[object_class_name][0])
                #modify undo redo
                self.undo_redo_operation(button_name, objects_class_name=object_class_name, post_operation_individual_objects=[new_object_for_undo_redo_history], IDF_dict_object_indices=[len(self.IDF_dict[object_class_name]) - 1])
                
                #reapply classes tree filter
                self.filter_class_tree_widget()
            
            elif button_name == "Paste":
                if self.clipboard.mimeData().hasText():
                    clipboard_string = self.clipboard.text()
                    #format is IDF,Object Class Name,field_0,field_1,...,field_n;Object Class Name,field_0,field_1,...,field_n;...
                    if len(clipboard_string) > 4 and clipboard_string.find("IDF," + object_class_name) == 0 and clipboard_string.count(object_class_name) == 1 + clipboard_string.count(";" + object_class_name): #all the clipboard_string objects are of type object_class_name
                        clipboard_string = clipboard_string[4:]
                        copied_object_strings = clipboard_string.split(";")[:-1]
                        
                        pasted_individual_objects_for_undo_redo_history = []
                        pasted_IDF_dict_object_indices = []
                        for copied_object_string in copied_object_strings:
                            copied_object_list = copied_object_string.split(",")
                            copied_object_class_name = copied_object_list[0]
                            #only paste if the copied objects are of the object class displayed in the table
                            if object_class_name == copied_object_class_name:
                                self.IDF_dict[object_class_name].append(copied_object_list[1:])
                                
                                pasted_object_index = len(self.IDF_dict[object_class_name]) - 1
                                pasted_individual_objects_for_undo_redo_history.append(copy.deepcopy(self.IDF_dict[object_class_name][pasted_object_index]))
                                pasted_IDF_dict_object_indices.append(pasted_object_index)
                        
                        #modify undo redo
                        self.undo_redo_operation(button_name, objects_class_name=object_class_name, post_operation_individual_objects=pasted_individual_objects_for_undo_redo_history, IDF_dict_object_indices=pasted_IDF_dict_object_indices)
                        
                        #reapply classes tree filter
                        self.filter_class_tree_widget()
            
            elif button_name in ["Delete", "Copy"]:
                selected_rows = set()
                selected_columns = set()
                for item in objects_table_widget.selectedItems():
                    selected_rows.add(item.row())
                    selected_columns.add(item.column())
                
                selected_rows = list(selected_rows)
                #selectedItems() does not work on cells that are empty, even though the cells are highlighted in the UI, so using only the top row is safer
                if len(selected_rows) != 1 or selected_rows[0] != 0:
                    QMessageBox.information(self, "Incorrect Selection", "Please only select cells in the top row to use " + button_name)
                else:
                    if button_name == "Delete":
                        deleted_individual_objects = []
                        deleted_individual_object_indices = []
                        for object_index in sorted(selected_columns, reverse=True):
                            deleted_individual_objects.append(copy.deepcopy(self.IDF_dict[object_class_name].pop(object_index)))
                            deleted_individual_object_indices.append(object_index)
                        
                        #modify undo redo
                        self.undo_redo_operation(button_name, objects_class_name=object_class_name, pre_operation_individual_objects=deleted_individual_objects, IDF_dict_object_indices=deleted_individual_object_indices)
                        
                        #reapply classes tree filter
                        self.filter_class_tree_widget()
                    
                    elif button_name == "Copy":
                        clipboard_string = "IDF,"
                        for object_index in selected_columns:
                            clipboard_string += object_class_name + "," + ",".join(self.IDF_dict[object_class_name][object_index]) + ";"
                            
                        self.clipboard.setText(clipboard_string)
    
    def populate_object_info_text_edit(self, group_name, object_class_name):
        self.object_info_text_edit.clear()
        self.object_info_text_edit.append(object_class_name)
        for memo_line in self.IDD_dict[group_name][object_class_name]["memo"]:
            self.object_info_text_edit.append(memo_line)
        self.object_info_text_edit.append("")
        
        field_IDs = self.field_IDs_dict[object_class_name]
        field_names = self.field_names_dict[object_class_name]
        for field_index in range(len(field_IDs)):
            ID = field_IDs[field_index]
            
            self.object_info_text_edit.append(field_names[field_index])
                
            if "note" in self.IDD_dict[group_name][object_class_name][ID].keys():
                for note_line in self.IDD_dict[group_name][object_class_name][ID]["note"]:
                    self.object_info_text_edit.append(note_line)
            
            if "required-field" in self.IDD_dict[group_name][object_class_name][ID].keys():
                self.object_info_text_edit.append("Required Field")
            
            if "type" in self.IDD_dict[group_name][object_class_name][ID].keys():
                type_value = self.IDD_dict[group_name][object_class_name][ID]["type"][0]
                if type_value == "integer":
                    self.object_info_text_edit.append("Integer")
                elif type_value == "real":
                    self.object_info_text_edit.append("Number")
                elif type_value == "alpha":
                    self.object_info_text_edit.append("Text")
                # elif type_value == "choice":
                # elif type_value == "object-list":
                elif type_value == "external-list":
                    if "autoRDDvariableMeter" == self.IDD_dict[group_name][object_class_name][ID]["external-list"][0]:
                        self.object_info_text_edit.append("Pick from the *.rdd file or *.mdd file.")
                    elif "autoRDDvariable" == self.IDD_dict[group_name][object_class_name][ID]["external-list"][0]:
                        self.object_info_text_edit.append("Pick from the *.rdd file.")
                    elif "autoRDDmeter" == self.IDD_dict[group_name][object_class_name][ID]["external-list"][0]:
                        self.object_info_text_edit.append("Pick from the *.mdd file.")
                # elif type_value == "node":
            
            if "autosizable" in self.IDD_dict[group_name][object_class_name][ID].keys():
                self.object_info_text_edit.append("autosizable")
            elif "autocalculatable" in self.IDD_dict[group_name][object_class_name][ID].keys():
                self.object_info_text_edit.append("autocalculatable")
            
            if "default" in self.IDD_dict[group_name][object_class_name][ID].keys():
                value_string = self.IDD_dict[group_name][object_class_name][ID]["default"][0]
                #add 0 in front of float string with a leading dot, like ".4"
                if "." == value_string[0]:
                    value_string = "0" + value_string
                
                if self.current_session_units_string == "IP":
                    _, _, field_multiplier, field_adder = self.unit_conversion(group_name, object_class_name, ID)
                    if field_multiplier is not None and field_adder is not None and field_multiplier != 1 and field_adder != 0:
                        value_string = str(float(value_string) * field_multiplier + field_adder)
                
                self.object_info_text_edit.append("Default: " + value_string)
            
            lower_bound_string = ""
            if "minimum" in self.IDD_dict[group_name][object_class_name][ID].keys():
                value_string = self.IDD_dict[group_name][object_class_name][ID]["minimum"][0]
                #add 0 in front of float string with a leading dot, like ".4"
                if "." == value_string[0]:
                    value_string = "0" + value_string
                
                if self.current_session_units_string == "IP":
                    _, _, field_multiplier, field_adder = self.unit_conversion(group_name, object_class_name, ID)
                    if field_multiplier is not None and field_adder is not None and field_multiplier != 1 and field_adder != 0:
                        value_string = str(float(value_string) * field_multiplier + field_adder)
                
                lower_bound_string = value_string + " <= "
            elif "minimum>" in self.IDD_dict[group_name][object_class_name][ID].keys():
                value_string = self.IDD_dict[group_name][object_class_name][ID]["minimum>"][0]
                #add 0 in front of float string with a leading dot, like ".4"
                if "." == value_string[0]:
                    value_string = "0" + value_string
                
                if self.current_session_units_string == "IP":
                    _, _, field_multiplier, field_adder = self.unit_conversion(group_name, object_class_name, ID)
                    if field_multiplier is not None and field_adder is not None and field_multiplier != 1 and field_adder != 0:
                        value_string = str(float(value_string) * field_multiplier + field_adder)
                
                lower_bound_string = value_string + " < "
            
            upper_bound_string = ""
            if "maximum" in self.IDD_dict[group_name][object_class_name][ID].keys():
                value_string = self.IDD_dict[group_name][object_class_name][ID]["maximum"][0]
                #add 0 in front of float string with a leading dot, like ".4"
                if "." == value_string[0]:
                    value_string = "0" + value_string
                
                if self.current_session_units_string == "IP":
                    _, _, field_multiplier, field_adder = self.unit_conversion(group_name, object_class_name, ID)
                    if field_multiplier is not None and field_adder is not None and field_multiplier != 1 and field_adder != 0:
                        value_string = str(float(value_string) * field_multiplier + field_adder)
                
                upper_bound_string = " <= " + value_string
            elif "maximum<" in self.IDD_dict[group_name][object_class_name][ID].keys():
                value_string = self.IDD_dict[group_name][object_class_name][ID]["maximum<"][0]
                #add 0 in front of float string with a leading dot, like ".4"
                if "." == value_string[0]:
                    value_string = "0" + value_string
                
                if self.current_session_units_string == "IP":
                    _, _, field_multiplier, field_adder = self.unit_conversion(group_name, object_class_name, ID)
                    if field_multiplier is not None and field_adder is not None and field_multiplier != 1 and field_adder != 0:
                        value_string = str(float(value_string) * field_multiplier + field_adder)
                
                upper_bound_string = " < " + value_string
            
            if len(lower_bound_string) > 0 or len(upper_bound_string):
                self.object_info_text_edit.append("Range: " + lower_bound_string + "value" + upper_bound_string)
                
            self.object_info_text_edit.append("")
        
        self.object_info_text_edit.verticalScrollBar().setValue(0)
    
    def on_top_objects_table_widget_right_click(self, position):
        self.open_objects_table_context_menu(self.top_objects_table_widget, self.top_radio_button_group, position)
    
    def on_bottom_objects_table_widget_right_click(self, position):
        self.open_objects_table_context_menu(self.bottom_objects_table_widget, self.bottom_radio_button_group, position)
    
    def open_objects_table_context_menu(self, objects_table_widget, button_group, position):
        row = objects_table_widget.indexAt(position).row()
        column = objects_table_widget.indexAt(position).column()
        
        if row is not None and row > 0 and button_group.checkedButton() is not None:
            object_class_name = button_group.checkedButton().objectName()
            group_name = self.group_name_from_object_class_name(object_class_name)
            field_IDs = self.field_IDs_dict[object_class_name]
            ID = field_IDs[row - 1]
            
            context_menu = QMenu()
            
            if "type" in self.IDD_dict[group_name][object_class_name][ID].keys() and self.IDD_dict[group_name][object_class_name][ID]["type"][0] in ["object-list", "node", "external-list"]:
                action = QAction("Field Choices", self)
                action.triggered.connect(lambda: self.on_object_table_context_menu_action_triggered("Field Choices", objects_table_widget, row, column, group_name, object_class_name, ID))
                context_menu.addAction(action)
            
            if "default" in self.IDD_dict[group_name][object_class_name][ID].keys():
                action = QAction(self.IDD_dict[group_name][object_class_name][ID]["default"][0] + " | default", self)
                action.triggered.connect(lambda: self.on_object_table_context_menu_action_triggered("default", objects_table_widget, row, column, group_name, object_class_name, ID))
                context_menu.addAction(action)
            
            if "minimum" in self.IDD_dict[group_name][object_class_name][ID].keys():
                action = QAction(self.IDD_dict[group_name][object_class_name][ID]["minimum"][0] + " | minimum", self)
                action.triggered.connect(lambda: self.on_object_table_context_menu_action_triggered("minimum", objects_table_widget, row, column, group_name, object_class_name, ID))
                context_menu.addAction(action)
            
            if "maximum" in self.IDD_dict[group_name][object_class_name][ID].keys():
                action = QAction(self.IDD_dict[group_name][object_class_name][ID]["maximum"][0] + " | maximum", self)
                action.triggered.connect(lambda : self.on_object_table_context_menu_action_triggered("maximum", objects_table_widget, row, column, group_name, object_class_name, ID))
                context_menu.addAction(action)
            
            if "autosizable" in self.IDD_dict[group_name][object_class_name][ID].keys():
                action = QAction("autosize | determined by software", self)
                action.triggered.connect(lambda: self.on_object_table_context_menu_action_triggered("autosize", objects_table_widget, row, column, group_name, object_class_name, ID))
                context_menu.addAction(action)
            
            if "autocalculatable" in self.IDD_dict[group_name][object_class_name][ID].keys():
                action = QAction("autocalculate | determined by software", self)
                action.triggered.connect(lambda: self.on_object_table_context_menu_action_triggered("autocalculate", objects_table_widget, row, column, group_name, object_class_name, ID))
                context_menu.addAction(action)
            
            if len(context_menu.actions()) > 0:
                context_menu.addSeparator()
            
            action = QAction("Copy", self)
            action.triggered.connect(lambda: self.on_object_table_context_menu_action_triggered("Copy", objects_table_widget, row, column, group_name, object_class_name, ID))
            context_menu.addAction(action)
            
            action = QAction("Paste", self)
            action.triggered.connect(lambda: self.on_object_table_context_menu_action_triggered("Paste", objects_table_widget, row, column, group_name, object_class_name, ID))
            context_menu.addAction(action)
        
            context_menu.exec(objects_table_widget.viewport().mapToGlobal(position))
        
    def on_object_table_context_menu_action_triggered(self, operation, objects_table_widget, row, column, group_name, object_class_name, ID):
        item = objects_table_widget.item(row, column)
        
        if operation == "Copy":
            if item is None:
                self.clipboard.setText("")
            else:
                self.clipboard.setText(item.text())
            
        else:
            if operation == "Paste" and self.clipboard.mimeData().hasText():
                if item is None:
                    objects_table_widget.setItem(row, column, QTableWidgetItem(self.clipboard.text()))
                else:
                    item.setText(self.clipboard.text())
            
            elif operation == "Field Choices":
                if "object-list" == self.IDD_dict[group_name][object_class_name][ID]["type"][0]:
                    valid_choices = self.field_choices(self.IDD_dict[group_name][object_class_name][ID]["object-list"])
                    
                    if item is None:
                        item = QTableWidgetItem()
                        self.open_popup_window("Field Choices", valid_choices, item)
                        objects_table_widget.setItem(row, column, item)
                    else:
                        self.open_popup_window("Field Choices", valid_choices, item)
                
                elif "node" == self.IDD_dict[group_name][object_class_name][ID]["type"][0]:
                    valid_choices = []
                    for object_class_name, field_index in self.node_object_fields_list:
                        for object_list in self.IDF_dict[object_class_name]:
                            if field_index < len(object_list) and object_list[field_index] != "":
                                valid_choices.append(object_list[field_index])
                    
                    if item is None:
                        item = QTableWidgetItem()
                        self.open_popup_window("Field Choices", valid_choices, item)
                        objects_table_widget.setItem(row, column, item)
                    else:
                        self.open_popup_window("Field Choices", valid_choices, item)
                
                elif "external-list" == self.IDD_dict[group_name][object_class_name][ID]["type"][0]:
                    if "autoRDDvariableMeter" == self.IDD_dict[group_name][object_class_name][ID]["external-list"][0]:
                        QMessageBox.information(self, "Field Choices", "Pick from the *.rdd file or *.mdd file.\n\nIn order to generate the *.rdd and *.mdd files, an Output:VariableDictionary object must exist with \"Key Field\" set to \"IDF\" and the *.idf file simulated.")
                    elif "autoRDDvariable" == self.IDD_dict[group_name][object_class_name][ID]["external-list"][0]:
                        QMessageBox.information(self, "Field Choices", "Pick from the *.rdd file.\n\nIn order to generate the *.rdd file, an Output:VariableDictionary object must exist with \"Key Field\" set to \"IDF\" and the *.idf file simulated.")
                    elif "autoRDDmeter" == self.IDD_dict[group_name][object_class_name][ID]["external-list"][0]:
                        QMessageBox.information(self, "Field Choices", "Pick from the *.mdd file.\n\nIn order to generate the *.mdd file, an Output:VariableDictionary object must exist with \"Key Field\" set to \"IDF\" and the *.idf file simulated.")
            
            elif operation in ["default", "minimum", "maximum"]:
                text = self.IDD_dict[group_name][object_class_name][ID][operation][0]
                if item is None:
                    objects_table_widget.setItem(row, column, QTableWidgetItem(text))
                else:
                    item.setText(text)
            
            elif operation in ["autosize", "autocalculate"]:
                if item is None:
                    objects_table_widget.setItem(row, column, QTableWidgetItem(operation))
                else:
                    item.setText(operation)
    
    def on_top_objects_table_widget_cell_changed(self, row, column):
        self.objects_table_cell_changed(self.top_radio_button_group.checkedButton().objectName(), self.top_objects_table_widget, row, column)
    
    def on_bottom_objects_table_widget_cell_changed(self, row, column):
        self.objects_table_cell_changed(self.bottom_radio_button_group.checkedButton().objectName(), self.bottom_objects_table_widget, row, column)
    
    def load_displayed_file_tabs(self):
        #remove all previous tabs
        for tab_displayed_filename in self.displayed_file_tabs_dict.keys():
            self.tabs.removeTab(self.tabs.indexOf(self.displayed_file_tabs_dict[tab_displayed_filename]))
        self.displayed_file_tabs_dict = {}
        
        idf_file_info = QFileInfo(self.selected_IDF_path_line_edit.text())
        if idf_file_info.exists():
            idf_directory_path = idf_file_info.absoluteDir().path()
            idf_filename = idf_file_info.fileName()[:-4] #remove ".idf" from the end
            
            for render_type, displayed_files_as_type_list in [["Text",self.current_session_displayed_files_as_text_list],["CSV",self.current_session_displayed_files_as_CSV_list],["HTML",self.current_session_displayed_files_as_HTML_list]]:
                for tab_displayed_filename in displayed_files_as_type_list:
                    displayed_file_path = os.path.join(idf_directory_path, tab_displayed_filename.replace("<IDF FILE>", idf_filename))
                    
                    try:
                        file_content = None
                        with open(displayed_file_path, "r") as displayed_file:
                            file_content = displayed_file.read()
                            
                        tab_widget = None
                        if render_type == "Text":
                            tab_widget = QTextEdit()
                            tab_widget.setReadOnly(True)
                            tab_widget.setPlainText(file_content)
                        elif render_type == "CSV":
                            csv = file_content.splitlines()
                            longest_row = 0
                            for row_index in range(len(csv)):
                                csv[row_index] = csv[row_index].split(",")
                                longest_row = max(longest_row, len(csv[row_index]))
                            
                            tab_widget = QTableWidget()
                            tab_widget.setRowCount(len(csv))
                            tab_widget.setColumnCount(longest_row)
                            for row_index in range(len(csv)):
                                for column_index in range(len(csv[row_index])):
                                    item = QTableWidgetItem(csv[row_index][column_index])
                                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                                    tab_widget.setItem(row_index, column_index, item)
                        elif render_type == "HTML":
                            tab_widget = QTextEdit()
                            tab_widget.setReadOnly(True)
                            tab_widget.setHtml(file_content)
                    except:
                        tab_widget = QTextEdit()
                        tab_widget.setReadOnly(True)
                        tab_widget.setPlainText("Unable to display contents of " + displayed_file_path + " file.")
                    finally:
                        self.displayed_file_tabs_dict[tab_displayed_filename] = tab_widget
                        self.tabs.addTab(tab_widget, tab_displayed_filename)
    
    def objects_table_widget_set_field_text(self, objects_table_widget, row, column, text):
        item = objects_table_widget.item(row, column)
        #there is no QTableWidgetItem in the cell if the cell was never assigned a value
        if item is None:
            objects_table_widget.setItem(row, column, QTableWidgetItem(text))
        else:
            item.setText(text)
    
    def objects_table_cell_changed(self, object_class_name, objects_table_widget, row, column):
        #for undo redo
        pre_operation_individual_objects = [copy.deepcopy(self.IDF_dict[object_class_name][column])]
        
        group_name = self.group_name_from_object_class_name(object_class_name)
        field_IDs = self.field_IDs_dict[object_class_name]
        ID = field_IDs[row - 1]
        
        field_text = objects_table_widget.item(row, column).text()
        if "," in field_text or ";" in field_text or "!" in field_text:
            QMessageBox.warning(self, "Invalid Characters", "Comma (,), semicolon (;), and exclamation point (!) are illegal characters and can result in a malformed *.idf file being written.")
        #first remove illegal characters
        #second remove leading and trailing white space
        field_text = field_text.replace(",", "").replace(";", "").replace("!", "").strip()
        
        #block Signals so cellChanged isn't triggered twice for cleaning of original text being rewritten and also any new fields filled with ""
        objects_table_widget.blockSignals(True)
        
        #change the cell contents to the possibly modified field_text
        self.objects_table_widget_set_field_text(objects_table_widget, row, column, field_text)
        
        #lengthen the object field list if it's not long enough
        if len(self.IDF_dict[object_class_name][column]) <= row - 1:
            previous_length = len(self.IDF_dict[object_class_name][column])
            new_length = row
            self.IDF_dict[object_class_name][column] += [None] * (new_length - previous_length)
            #all the fields between the previous_length and new_length, not including the previous_length and new_length, are filled with "" and this function is called since they have changed
            for field_index in range(previous_length, new_length - 1):
                self.IDF_dict[object_class_name][column][field_index] = ""
                self.objects_table_widget_set_field_text(objects_table_widget, field_index + 1, column, "")
        
        #allow Signals again now that cleaning of original text and padding empty "" fields is over
        objects_table_widget.blockSignals(False)
        
        if self.current_session_units_string == "SI":
            self.IDF_dict[object_class_name][column][row - 1] = field_text
        
        elif self.current_session_units_string == "IP":
            displayed_si_units, displayed_ip_units, field_multiplier, field_adder = self.unit_conversion(group_name, object_class_name, ID)
            
            if field_multiplier is None or field_adder is None: #special case for hh:mm unit
                self.IDF_dict[object_class_name][column][row - 1] = field_text
            else:
                output_representation = self.string_is_alphanumeric_int_float(field_text)
                if type(output_representation) is int or type(output_representation) is float:
                        IDF_dict_field_text = str((output_representation - field_adder) / field_multiplier)
                        self.IDF_dict[object_class_name][column][row - 1] = IDF_dict_field_text
                elif type(output_representation) is str:
                    #not an int or a float so write to the IDF_dict whether it's valid or invalid for the field
                    self.IDF_dict[object_class_name][column][row - 1] = field_text
        
        #modify undo redo
        self.undo_redo_operation("Field Changed", objects_class_name=object_class_name, pre_operation_individual_objects=pre_operation_individual_objects, post_operation_individual_objects=[copy.deepcopy(self.IDF_dict[object_class_name][column])], IDF_dict_object_indices=[column])
        
        #changes cell color to signify invalid field contents
        objects_table_widget.blockSignals(True) #block Signals so changing the cell color does trigger cellChanged
        self.apply_table_cell_validity_color(object_class_name, objects_table_widget, row, column)
        objects_table_widget.blockSignals(False) #allow Signals again
        
        #reapply classes tree filter
        self.filter_class_tree_widget()
        
        objects_table_widget.resizeColumnsToContents()
    
    #invalid text will have an orange background
    def apply_table_cell_validity_color(self, object_class_name, objects_table_widget, row, column):
        group_name = self.group_name_from_object_class_name(object_class_name)
        field_IDs = self.field_IDs_dict[object_class_name]
        ID = field_IDs[row - 1]
        
        #use the IDF_dict text so there's no case checking for SI vs IP units
        field_text = self.IDF_dict[object_class_name][column][row - 1]

        if field_text == "" and "required-field" in self.IDD_dict[group_name][object_class_name][ID].keys():
            objects_table_widget.item(row, column).setBackground(self.invalid_object_field_brush)
            return
            
        if field_text == "" and "default" in self.IDD_dict[group_name][object_class_name][ID].keys():
            objects_table_widget.item(row, column).setBackground(self.valid_object_field_brush)
            return
        
        if "type" in self.IDD_dict[group_name][object_class_name][ID].keys() and "integer" == self.IDD_dict[group_name][object_class_name][ID]["type"][0]:
            #special valid case
            if "autosizable" in self.IDD_dict[group_name][object_class_name][ID].keys() and field_text.lower() == "autosize":
                objects_table_widget.item(row, column).setBackground(self.valid_object_field_brush)
                return
            elif "autocalculatable" in self.IDD_dict[group_name][object_class_name][ID].keys() and field_text.lower() == "autocalculate":
                objects_table_widget.item(row, column).setBackground(self.valid_object_field_brush)
                return
            elif field_text == "":
                objects_table_widget.item(row, column).setBackground(self.valid_object_field_brush)
                return
            
            field_int = self.string_is_alphanumeric_int_float(field_text)
            if type(field_int) is int:
                if "minimum" in self.IDD_dict[group_name][object_class_name][ID].keys() and field_int < int(self.IDD_dict[group_name][object_class_name][ID]["minimum"][0]):
                    objects_table_widget.item(row, column).setBackground(self.invalid_object_field_brush)
                    return
                if "minimum>" in self.IDD_dict[group_name][object_class_name][ID].keys() and field_int <= int(self.IDD_dict[group_name][object_class_name][ID]["minimum>"][0]):
                    objects_table_widget.item(row, column).setBackground(self.invalid_object_field_brush)
                    return
                if "maximum" in self.IDD_dict[group_name][object_class_name][ID].keys() and int(self.IDD_dict[group_name][object_class_name][ID]["maximum"][0]) < field_int:
                    objects_table_widget.item(row, column).setBackground(self.invalid_object_field_brush)
                    return
                if "maximum<" in self.IDD_dict[group_name][object_class_name][ID].keys() and int(self.IDD_dict[group_name][object_class_name][ID]["maximum<"][0]) <= field_int:
                    objects_table_widget.item(row, column).setBackground(self.invalid_object_field_brush)
                    return
            else:
                objects_table_widget.item(row, column).setBackground(self.invalid_object_field_brush)
                return
        
        #if a type is not defined but minimum or minimum> or maximum or maximum< is, the field is assumed to be a real
        elif ( ("type" in self.IDD_dict[group_name][object_class_name][ID].keys() and "real" == self.IDD_dict[group_name][object_class_name][ID]["type"][0]) or
            "minimum" in self.IDD_dict[group_name][object_class_name][ID].keys() or "minimum>" in self.IDD_dict[group_name][object_class_name][ID].keys() or "maximum" in self.IDD_dict[group_name][object_class_name][ID].keys() or "maximum<" in self.IDD_dict[group_name][object_class_name][ID].keys()):
            #special valid case
            if "autosizable" in self.IDD_dict[group_name][object_class_name][ID].keys() and field_text.lower() == "autosize":
                objects_table_widget.item(row, column).setBackground(self.valid_object_field_brush)
                return
            elif "autocalculatable" in self.IDD_dict[group_name][object_class_name][ID].keys() and field_text.lower() == "autocalculate":
                objects_table_widget.item(row, column).setBackground(self.valid_object_field_brush)
                return
            elif field_text == "":
                objects_table_widget.item(row, column).setBackground(self.valid_object_field_brush)
                return
            
            field_float_or_int = self.string_is_alphanumeric_int_float(field_text)
            if type(field_float_or_int) is float or type(field_float_or_int) is int:
                if "minimum" in self.IDD_dict[group_name][object_class_name][ID].keys() and field_float_or_int < float(self.IDD_dict[group_name][object_class_name][ID]["minimum"][0]):
                    objects_table_widget.item(row, column).setBackground(self.invalid_object_field_brush)
                    return
                if "minimum>" in self.IDD_dict[group_name][object_class_name][ID].keys() and field_float_or_int <= float(self.IDD_dict[group_name][object_class_name][ID]["minimum>"][0]):
                    objects_table_widget.item(row, column).setBackground(self.invalid_object_field_brush)
                    return
                if "maximum" in self.IDD_dict[group_name][object_class_name][ID].keys() and float(self.IDD_dict[group_name][object_class_name][ID]["maximum"][0]) < field_float_or_int:
                    objects_table_widget.item(row, column).setBackground(self.invalid_object_field_brush)
                    return
                if "maximum<" in self.IDD_dict[group_name][object_class_name][ID].keys() and float(self.IDD_dict[group_name][object_class_name][ID]["maximum<"][0]) <= field_float_or_int:
                    objects_table_widget.item(row, column).setBackground(self.invalid_object_field_brush)
                    return
            else:
                objects_table_widget.item(row, column).setBackground(self.invalid_object_field_brush)
                return
                
        elif "type" in self.IDD_dict[group_name][object_class_name][ID].keys() and "object-list" == self.IDD_dict[group_name][object_class_name][ID]["type"][0] and field_text != "":
            valid_choices = self.field_choices(self.IDD_dict[group_name][object_class_name][ID]["object-list"])
            if field_text not in valid_choices:
                objects_table_widget.item(row, column).setBackground(self.invalid_object_field_brush)
                return
        
        #passed all tests and the field_text is valid
        objects_table_widget.item(row, column).setBackground(self.valid_object_field_brush)
    
    def IDF_object_combo_box_field_changed(self, text, object_class_name, object_index, field_index):
        #for undo redo
        pre_operation_individual_objects = [copy.deepcopy(self.IDF_dict[object_class_name][object_index])]
        
        self.IDF_dict[object_class_name][object_index][field_index] = text
        
        #modify undo redo
        self.undo_redo_operation("Field Changed", objects_class_name=object_class_name, pre_operation_individual_objects=pre_operation_individual_objects, post_operation_individual_objects=[copy.deepcopy(self.IDF_dict[object_class_name][object_index])], IDF_dict_object_indices=[object_index])


#this class is so when scrolling down a long object in a table with combo boxes, the combo box selection aren't scrolled through with the mouse wheel, which would change the field value
class CustomComboBox(QComboBox):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFocusPolicy(Qt.NoFocus) #prevents mouse scroll wheel from changing the selection on hover
    
    def wheelEvent(self, event: QWheelEvent):
        if not self.hasFocus():
            event.ignore()
        else:
            super().wheelEvent(event)


class AvailableVersionDialog(QDialog):
    def __init__(self, main_window_self):
        super().__init__()
        
        #used to easily access variables in MainWindow
        self.main_window_self = main_window_self
        
        #set window title
        self.setWindowTitle("Available Version")
        
        v_layout = QVBoxLayout()
        self.setLayout(v_layout)
        
        button_box = QDialogButtonBox()
        button_box.setCenterButtons(True)
        
        v_layout.addWidget(QLabel("You are running " + APPLICATION_NAME + " " + self.main_window_self.BEM_File_editor_version + " and version " + self.main_window_self.available_BEM_File_Editor_version + " is available for download.\n\nYou can disable this prompt on application open in View->Application Settings."))
            
        button_box.addButton(QPushButton("Download Link"), QDialogButtonBox.ButtonRole.AcceptRole)
        button_box.addButton(QDialogButtonBox.Close)
        button_box.accepted.connect(lambda: QDesktopServices.openUrl(QUrl(self.main_window_self.website_downloads_section_url)))
        button_box.rejected.connect(self.close)
        
        v_layout.addWidget(button_box)


class ApplicationSettingsDialog(QDialog):
    def __init__(self, main_window_self):
        super().__init__()
        
        #used to easily access variables in MainWindow
        self.main_window_self = main_window_self
        
        #set window title
        self.setWindowTitle("Application Settings")
        
        v_layout = QVBoxLayout()
        self.setLayout(v_layout)
        
        v_layout.addWidget(QLabel("These settings are saved between sessions of your " + APPLICATION_NAME + " installation."))
        
        #Font Size
        h_layout = QHBoxLayout()
        self.font_point_size_label = QLabel("Font Point Size")
        h_layout.addWidget(self.font_point_size_label)
        self.font_point_size_combo_box = CustomComboBox()
        self.font_point_size_combo_box.addItems(["6","7","8","9","10","11","12","14","16","18","20","22","24","26","28","36","48","72"])
        self.font_point_size_combo_box.setCurrentText(str(self.main_window_self.current_session_font_point_size_int))
        self.font_point_size_combo_box.currentTextChanged.connect(self.on_font_point_size_combo_box_text_changed)
        h_layout.addWidget(self.font_point_size_combo_box)
        v_layout.addLayout(h_layout)
        
        #Disable Update Prompt
        h_layout = QHBoxLayout()
        h_layout.addWidget(QLabel("Disable Update Prompt"))
        self.disable_update_prompt_check_box = QCheckBox()
        self.disable_update_prompt_check_box.setChecked(self.main_window_self.current_session_disable_update_prompt_bool)
        h_layout.addWidget(self.disable_update_prompt_check_box)
        v_layout.addLayout(h_layout)
        
        #Show Python Console Tab
        h_layout = QHBoxLayout()
        h_layout.addWidget(QLabel("Show Python Console Tab"))
        self.show_python_console_tab_check_box = QCheckBox()
        self.show_python_console_tab_check_box.setChecked(self.main_window_self.current_session_show_python_console_tab_bool)
        h_layout.addWidget(self.show_python_console_tab_check_box)
        v_layout.addLayout(h_layout)
        
        #EnergyPlus installation directories
        v_layout.addWidget(QLabel("Installation Directories"))
        self.paths_line_edits = {}
        for EnergyPlus_version_string in self.main_window_self.all_suported_EnergyPlus_versions:
            h_layout = QHBoxLayout()
            
            h_layout.addWidget(QLabel(EnergyPlus_version_string))
            self.paths_line_edits[EnergyPlus_version_string] = QLineEdit(self.main_window_self.current_session_EnergyPlus_installation_directories_dict[EnergyPlus_version_string])
            self.paths_line_edits[EnergyPlus_version_string].setReadOnly(True)
            h_layout.addWidget(self.paths_line_edits[EnergyPlus_version_string])
            set_button = QPushButton("Set", default=False, autoDefault=False)
            set_button.clicked.connect(lambda checked, EnergyPlus_version_string=EnergyPlus_version_string: self.on_set_EnergyPlus_installation_directory_button_clicked(EnergyPlus_version_string))
            h_layout.addWidget(set_button)
            
            v_layout.addLayout(h_layout)
        
        #Files displayed in tabs as text or CSV or HTML
        v_layout.addWidget(QLabel("Displayed Files"))
        v_layout.addWidget(QLabel("Separate file names by commas with <IDF FILE> used to represent the name of the loaded IDF file."))
        v_layout.addWidget(QLabel("See Help->EnergyPlus Output Details and Examples for available files."))
        
        h_layout = QHBoxLayout()
        h_layout.addWidget(QLabel("Render as Text"))
        self.render_as_text_line_edit = QLineEdit(",".join(self.main_window_self.current_session_displayed_files_as_text_list))
        h_layout.addWidget(self.render_as_text_line_edit)
        v_layout.addLayout(h_layout)
        
        h_layout = QHBoxLayout()
        h_layout.addWidget(QLabel("Render as CSV"))
        self.render_as_CSV_line_edit = QLineEdit(",".join(self.main_window_self.current_session_displayed_files_as_CSV_list))
        h_layout.addWidget(self.render_as_CSV_line_edit)
        v_layout.addLayout(h_layout)
        
        h_layout = QHBoxLayout()
        h_layout.addWidget(QLabel("Render as HTML"))
        self.render_as_HTML_line_edit = QLineEdit(",".join(self.main_window_self.current_session_displayed_files_as_HTML_list))
        h_layout.addWidget(self.render_as_HTML_line_edit)
        v_layout.addLayout(h_layout)
        
        #default=False with autoDefault=False on buttons prevents QDialog from activating a button on pressing enter key
        show_defaults_button = QPushButton("Show Defaults", default=False, autoDefault=False)
        cancel_button = QPushButton("Cancel")
        apply_changes_button = QPushButton("Apply Changes", default=False, autoDefault=False)
        
        button_box = QDialogButtonBox()
        button_box.setCenterButtons(True)
        button_box.addButton(show_defaults_button, QDialogButtonBox.ResetRole)
        button_box.addButton(apply_changes_button, QDialogButtonBox.ApplyRole)
        
        show_defaults_button.clicked.connect(self.on_show_default_settings_clicked)
        apply_changes_button.clicked.connect(self.on_apply_changes_clicked)
        
        v_layout.addWidget(button_box)
        
    def on_font_point_size_combo_box_text_changed(self):
        font = self.font_point_size_label.font()
        font.setPointSize(int(self.font_point_size_combo_box.currentText()))
        self.font_point_size_label.setFont(font)
    
    def on_set_EnergyPlus_installation_directory_button_clicked(self, EnergyPlus_version_string):
        directory_path = QFileDialog.getExistingDirectory(self, "Select Folder")
        self.paths_line_edits[EnergyPlus_version_string].setText(directory_path)
    
    def on_show_default_settings_clicked(self):
        self.font_point_size_combo_box.setCurrentText(str(self.main_window_self.settings_defaults_dict["font_point_size_int"]))
        self.disable_update_prompt_check_box.setChecked(self.main_window_self.settings_defaults_dict["disable_update_prompt_bool"])
        self.show_python_console_tab_check_box.setChecked(self.main_window_self.settings_defaults_dict["show_python_console_tab_bool"])
        for EnergyPlus_version_string in self.main_window_self.all_suported_EnergyPlus_versions:
            self.paths_line_edits[EnergyPlus_version_string].setText(self.main_window_self.settings_defaults_dict["EnergyPlus_installation_directories_dict"][EnergyPlus_version_string])
        self.render_as_text_line_edit.setText(",".join(self.main_window_self.settings_defaults_dict["displayed_files_as_text_list"]))
        self.render_as_CSV_line_edit.setText(",".join(self.main_window_self.settings_defaults_dict["displayed_files_as_CSV_list"]))
        self.render_as_HTML_line_edit.setText(",".join(self.main_window_self.settings_defaults_dict["displayed_files_as_HTML_list"]))
    
    def on_apply_changes_clicked(self):
        if self.main_window_self.current_session_font_point_size_int != int(self.font_point_size_combo_box.currentText()):
            self.main_window_self.current_session_font_point_size_int = int(self.font_point_size_combo_box.currentText())
            QMessageBox.warning(self, "Font Changed", "The Font Point Size has been changed. Since fonts are partially handled by the operating system, you will need to exit and reopen the " + APPLICATION_NAME + " for changes to take effect\n\nKeep in mind that there are some parts of the window that are controlled directly by the operating system, such as the window's title, the size of File, Edit, View, and Help in the menu bar, and others. To change the size of all text, you are better off using accessibility options in your operating system that controls the font size in all applications.")
        self.main_window_self.current_session_disable_update_prompt_bool = self.disable_update_prompt_check_box.isChecked()
        
        self.main_window_self.current_session_show_python_console_tab_bool = self.show_python_console_tab_check_box.isChecked()
        self.main_window_self.show_python_console_tab()
        
        for EnergyPlus_version_string in self.main_window_self.all_suported_EnergyPlus_versions:
            self.main_window_self.current_session_EnergyPlus_installation_directories_dict[EnergyPlus_version_string] = self.paths_line_edits[EnergyPlus_version_string].text()
        
        filenames_list = self.render_as_text_line_edit.text().split(",")
        filenames_list = [filename.strip() for filename in filenames_list]
        filenames_list = [filename for filename in filenames_list if filename != ""]
        self.main_window_self.current_session_displayed_files_as_text_list = filenames_list
        
        filenames_list = self.render_as_CSV_line_edit.text().split(",")
        filenames_list = [filename.strip() for filename in filenames_list]
        filenames_list = [filename for filename in filenames_list if filename != ""]
        self.main_window_self.current_session_displayed_files_as_CSV_list = filenames_list
        
        filenames_list = self.render_as_HTML_line_edit.text().split(",")
        filenames_list = [filename.strip() for filename in filenames_list]
        filenames_list = [filename for filename in filenames_list if filename != ""]
        self.main_window_self.current_session_displayed_files_as_HTML_list = filenames_list
        
        self.main_window_self.load_displayed_file_tabs()


class UndoRedoPreviewDialog(QDialog):
    def __init__(self, main_window_self):
        super().__init__()
        
        #used to easily access variables in MainWindow
        self.main_window_self = main_window_self
        
        #set window title
        self.setWindowTitle("Undo Redo Preview")
        
        #default=False with autoDefault=False on buttons prevents QDialog from activating a button on pressing enter key
        post_undo_label = QLabel("Post Undo")
        self.post_undo_object_table_widget = QTableWidget()
        self.post_undo_object_table_widget.horizontalHeader().setVisible(False)
        undo_button = QPushButton("Undo", default=False, autoDefault=False)
        undo_button.clicked.connect(lambda: self.on_undo_redo_button_clicked("Undo"))
        pre_undo_label = QLabel("Current State")
        self.current_undo_object_table_widget = QTableWidget()
        self.current_undo_object_table_widget.horizontalHeader().setVisible(False)
        
        pre_redo_label = QLabel("Current State")
        self.current_redo_object_table_widget = QTableWidget()
        self.current_redo_object_table_widget.horizontalHeader().setVisible(False)
        redo_button = QPushButton("Redo", default=False, autoDefault=False)
        redo_button.clicked.connect(lambda: self.on_undo_redo_button_clicked("Redo"))
        post_redo_label = QLabel("Post Redo")
        self.post_redo_object_table_widget = QTableWidget()
        self.post_redo_object_table_widget.horizontalHeader().setVisible(False)
        
        undo_widget = QWidget()
        
        v_layout = QVBoxLayout()
        undo_widget.setLayout(v_layout)
        
        v_layout.addWidget(post_undo_label)
        v_layout.addWidget(self.post_undo_object_table_widget)
        v_layout.addWidget(undo_button)
        v_layout.addWidget(pre_undo_label)
        v_layout.addWidget(self.current_undo_object_table_widget)
                
        redo_widget = QWidget()
        
        v_layout = QVBoxLayout()
        redo_widget.setLayout(v_layout)
        
        v_layout.addWidget(pre_redo_label)
        v_layout.addWidget(self.current_redo_object_table_widget)
        v_layout.addWidget(redo_button)
        v_layout.addWidget(post_redo_label)
        v_layout.addWidget(self.post_redo_object_table_widget)
        
        splitter = QSplitter(Qt.Vertical)
        #needed since the default QDialog background is the same color as the default splitter handle
        splitter.setStyleSheet("QSplitterHandle {background-color: #E3E3E3;}")
        splitter.addWidget(undo_widget)
        splitter.addWidget(redo_widget)
        
        v_layout = QVBoxLayout()
        v_layout.addWidget(splitter)
        
        self.setLayout(v_layout)
        
        self.populate_all_undo_redo_tables()
    
    def on_undo_redo_button_clicked(self, operation):
        self.main_window_self.undo_redo_operation(operation)
        self.populate_all_undo_redo_tables()
    
    def populate_all_undo_redo_tables(self):
        self.post_undo_object_table_widget.clear()
        self.post_undo_object_table_widget.setRowCount(0)
        self.post_undo_object_table_widget.setColumnCount(0)
        self.current_undo_object_table_widget.clear()
        self.current_undo_object_table_widget.setRowCount(0)
        self.current_undo_object_table_widget.setColumnCount(0)
        
        self.current_redo_object_table_widget.clear()
        self.current_redo_object_table_widget.setRowCount(0)
        self.current_redo_object_table_widget.setColumnCount(0)
        self.post_redo_object_table_widget.clear()
        self.post_redo_object_table_widget.setRowCount(0)
        self.post_redo_object_table_widget.setColumnCount(0)
        
        #undo tables
        if len(self.main_window_self.undo_history) > 0:
            item = self.main_window_self.undo_history[-1]
            
            item_undo_redo_string = self.main_window_self.item_undo_redo_string(item[0])
            item_objects_class_name = item[1]
            item_pre_operation_individual_objects = item[2]
            item_post_operation_individual_objects = item[3]
            item_IDF_dict_object_indices = item[4]
            
            if item_undo_redo_string in ["New", "Paste"]:
                max_object_length = -1
                for individual_object in item_post_operation_individual_objects:
                    max_object_length = max(max_object_length,len(individual_object))
                self.populate_individual_table(self.post_undo_object_table_widget, item_objects_class_name, [], [], max_object_length)
                self.populate_individual_table(self.current_undo_object_table_widget, item_objects_class_name, item_post_operation_individual_objects, item_IDF_dict_object_indices, max_object_length)
            
            elif item_undo_redo_string == "Delete":
                max_object_length = -1
                for individual_object in item_pre_operation_individual_objects:
                    max_object_length = max(max_object_length,len(individual_object))
                reversed_item_pre_operation_individual_objects = item_pre_operation_individual_objects[::-1]
                reversed_item_IDF_dict_object_indices = item_IDF_dict_object_indices[::-1]
                self.populate_individual_table(self.post_undo_object_table_widget, item_objects_class_name, reversed_item_pre_operation_individual_objects, reversed_item_IDF_dict_object_indices, max_object_length)
                self.populate_individual_table(self.current_undo_object_table_widget, item_objects_class_name, [], [], max_object_length)
            
            elif item_undo_redo_string == "Field Changed":
                max_object_length = -1
                for individual_object in item_pre_operation_individual_objects + item_post_operation_individual_objects:
                    max_object_length = max(max_object_length,len(individual_object))
                self.populate_individual_table(self.post_undo_object_table_widget, item_objects_class_name, item_pre_operation_individual_objects, item_IDF_dict_object_indices, max_object_length)
                self.populate_individual_table(self.current_undo_object_table_widget, item_objects_class_name, item_post_operation_individual_objects, item_IDF_dict_object_indices, max_object_length)
                
                max_length = max(len(item_pre_operation_individual_objects[0]),len(item_post_operation_individual_objects[0]))
                if len(item_pre_operation_individual_objects[0]) == len(item_post_operation_individual_objects[0]):
                    for field_index in range(max_length):
                        if item_pre_operation_individual_objects[0][field_index] != item_post_operation_individual_objects[0][field_index]:
                            self.current_undo_object_table_widget.item(field_index + 1, 0).setBackground(self.main_window_self.invalid_object_field_brush)
                            self.post_undo_object_table_widget.item(field_index + 1, 0).setBackground(self.main_window_self.invalid_object_field_brush)
                            break
                else:
                    for table_widget in [self.current_undo_object_table_widget,self.post_undo_object_table_widget]:
                        item = table_widget.item(max_length, 0)
                        if item is None:
                            item = QTableWidgetItem()
                            item.setBackground(self.main_window_self.invalid_object_field_brush)
                            table_widget.setItem(max_length, 0, item)
                        else:
                            item.setBackground(self.main_window_self.invalid_object_field_brush)
        
        #redo tables
        if len(self.main_window_self.redo_history) > 0:
            item = self.main_window_self.redo_history[0]
            
            item_undo_redo_string = self.main_window_self.item_undo_redo_string(item[0])
            item_objects_class_name = item[1]
            item_pre_operation_individual_objects = item[2]
            item_post_operation_individual_objects = item[3]
            item_IDF_dict_object_indices = item[4]
            
            if item_undo_redo_string in ["New", "Paste"]:
                max_object_length = -1
                for individual_object in item_post_operation_individual_objects:
                    max_object_length = max(max_object_length,len(individual_object))
                self.populate_individual_table(self.current_redo_object_table_widget, item_objects_class_name, [], [], max_object_length)
                self.populate_individual_table(self.post_redo_object_table_widget, item_objects_class_name, item_post_operation_individual_objects, item_IDF_dict_object_indices, max_object_length)
            
            elif item_undo_redo_string == "Delete":
                max_object_length = -1
                for individual_object in item_pre_operation_individual_objects:
                    max_object_length = max(max_object_length,len(individual_object))
                reversed_item_pre_operation_individual_objects = item_pre_operation_individual_objects[::-1]
                reversed_item_IDF_dict_object_indices = item_IDF_dict_object_indices[::-1]
                self.populate_individual_table(self.current_redo_object_table_widget, item_objects_class_name, reversed_item_pre_operation_individual_objects, reversed_item_IDF_dict_object_indices, max_object_length)
                self.populate_individual_table(self.post_redo_object_table_widget, item_objects_class_name, [], [], max_object_length)
            
            elif item_undo_redo_string == "Field Changed":
                max_object_length = -1
                for individual_object in item_pre_operation_individual_objects + item_post_operation_individual_objects:
                    max_object_length = max(max_object_length,len(individual_object))
                self.populate_individual_table(self.current_redo_object_table_widget, item_objects_class_name, item_pre_operation_individual_objects, item_IDF_dict_object_indices, max_object_length)
                self.populate_individual_table(self.post_redo_object_table_widget, item_objects_class_name, item_post_operation_individual_objects, item_IDF_dict_object_indices, max_object_length)
                
                if len(item_pre_operation_individual_objects[0]) == len(item_post_operation_individual_objects[0]):
                    for field_index in range(max_object_length):
                        if item_pre_operation_individual_objects[0][field_index] != item_post_operation_individual_objects[0][field_index]:
                            self.current_redo_object_table_widget.item(field_index + 1, 0).setBackground(self.main_window_self.invalid_object_field_brush)
                            self.post_redo_object_table_widget.item(field_index + 1, 0).setBackground(self.main_window_self.invalid_object_field_brush)
                            break
                else:
                    for table_widget in [self.current_redo_object_table_widget,self.post_redo_object_table_widget]:
                        item = table_widget.item(max_object_length, 0)
                        if item is None:
                            item = QTableWidgetItem()
                            item.setBackground(self.main_window_self.invalid_object_field_brush)
                            table_widget.setItem(max_object_length, 0, item)
                        else:
                            item.setBackground(self.main_window_self.invalid_object_field_brush)
    
    def populate_individual_table(self, objects_table_widget, object_class_name, individual_objects, object_numbering, max_object_length):
        group_name = self.main_window_self.group_name_from_object_class_name(object_class_name)
        field_IDs = self.main_window_self.field_IDs_dict[object_class_name]
        field_names = self.main_window_self.field_names_dict[object_class_name]
        
        #add vertical header
        objects_table_widget.clear()
        objects_table_widget.setRowCount(max_object_length + 1)
        header_strings = [""] * (max_object_length + 1)
        header_strings[0] = "Field [Units]"
        for field_index in range(max_object_length):
            ID = field_IDs[field_index]
            field_vertical_header = field_names[field_index]
            
            displayed_units = self.main_window_self.field_displayed_units(group_name, object_class_name, ID)
            if displayed_units is not None:
                field_vertical_header += " [" + displayed_units + "]"
            
            header_strings[field_index + 1] = field_vertical_header
        objects_table_widget.setVerticalHeaderLabels(header_strings)
        #add objects
        objects_table_widget.setColumnCount(len(individual_objects))
        for object_index in range(len(individual_objects)):
            item = QTableWidgetItem("Object " + str(object_numbering[object_index] + 1))
            item.setFlags(item.flags() & ~Qt.ItemIsEditable)
            objects_table_widget.setItem(0, object_index, item)
            
            individual_object = individual_objects[object_index]
            for field_index in range(min(len(individual_object),max_object_length)):
                ID = field_IDs[field_index]
                
                #ignore combo boxes and write every field as text
                field_text = individual_object[field_index]
                if self.main_window_self.current_session_units_string == "SI":
                    objects_table_widget.setItem(field_index + 1, object_index, QTableWidgetItem(field_text))
                
                elif self.main_window_self.current_session_units_string == "IP":
                    displayed_si_units, displayed_ip_units, field_multiplier, field_adder = self.main_window_self.unit_conversion(group_name, object_class_name, ID)
                    
                    if field_multiplier is None or field_adder is None: #special case for hh:mm unit
                        objects_table_widget.setItem(field_index + 1, object_index, QTableWidgetItem(field_text))
                    else:
                        output_representation = self.main_window_self.string_is_alphanumeric_int_float(field_text)
                        if type(output_representation) is int or type(output_representation) is float:
                                table_cell_text = str(output_representation * field_multiplier + field_adder)
                                objects_table_widget.setItem(field_index + 1, object_index, QTableWidgetItem(table_cell_text))
                        elif type(output_representation) is str:
                            #not an int or a float so write to the table whether it's valid or invalid for the field
                            objects_table_widget.setItem(field_index + 1, object_index, QTableWidgetItem(field_text))
        
        objects_table_widget.resizeColumnsToContents()


class FieldChoicesDialog(QDialog):
    def __init__(self, main_window_self, options_list, right_clicked_item):
        super().__init__()
        
        self.right_clicked_item = right_clicked_item
        
        #used to easily access variables in MainWindow
        self.main_window_self = main_window_self
        
        #set window title
        self.setWindowTitle("Field Choices")
        
        v_layout = QVBoxLayout()
        self.setLayout(v_layout)
        
        self.filter_options_line_edit = QLineEdit()
        self.filter_options_line_edit.setPlaceholderText("Filter Choices by Text")
        self.filter_options_line_edit.textEdited.connect(self.filter_options_table_widget)
        
        self.filter_options_case_sensitive_check_box = QCheckBox("Case Sensitive")
        self.filter_options_case_sensitive_check_box.stateChanged.connect(self.filter_options_table_widget)
        
        filter_options_layout = QHBoxLayout()
        filter_options_layout.addWidget(self.filter_options_line_edit)
        filter_options_layout.addWidget(self.filter_options_case_sensitive_check_box)
        filter_options_layout.setContentsMargins(0,0,0,0)
        
        filter_options_widget = QWidget()
        filter_options_widget.setLayout(filter_options_layout)
        
        v_layout.addWidget(filter_options_widget)
        
        v_layout.addWidget(QLabel("Double click an item to choose."))
        
        self.options_table_widget = QTableWidget()
        self.options_table_widget.cellDoubleClicked.connect(self.on_cell_double_clicked)
        self.options_table_widget.setRowCount(len(options_list))
        self.options_table_widget.setColumnCount(1)
        self.options_table_widget.setHorizontalHeaderLabels(["Name"])
        for row_index in range(len(options_list)):
            item = QTableWidgetItem(options_list[row_index])
            item.setFlags(item.flags() & ~Qt.ItemIsEditable)
            self.options_table_widget.setItem(row_index, 0, item)
        self.options_table_widget.resizeColumnsToContents()
        
        v_layout.addWidget(self.options_table_widget)
        
    def filter_options_table_widget(self):
        for row in range(self.options_table_widget.rowCount()):
            item = self.options_table_widget.item(row, 0)
            if ( self.filter_options_line_edit.text() == "" or
            (self.filter_options_case_sensitive_check_box.isChecked() and self.filter_options_line_edit.text() in item.text()) or 
            (not self.filter_options_case_sensitive_check_box.isChecked() and self.filter_options_line_edit.text().lower() in item.text().lower()) ):
                self.options_table_widget.setRowHidden(row, False)
            else:
                self.options_table_widget.setRowHidden(row, True)
    
    def on_cell_double_clicked(self, row, column):
        self.right_clicked_item.setText(self.options_table_widget.item(row, column).text())
        self.close()


if __name__ == "__main__":
    #since these are defined here, they are available everywhere
    APPLICATION_NAME = "BEM File Editor"
    PYTHON_CONSOLE_FILEPATH = os.path.join(QStandardPaths.writableLocation(QStandardPaths.AppDataLocation), APPLICATION_NAME, "python_console_output.log") #application has permission to create and write to this file at this location
    
    #backup the original stdout and stderr
    original_stdout = sys.stdout
    original_stderr = sys.stderr
    
    #file to redirect python console output to
    os.makedirs(os.path.dirname(PYTHON_CONSOLE_FILEPATH), exist_ok=True)
    with open(PYTHON_CONSOLE_FILEPATH, mode="a", buffering=1) as python_console_output_file: #buffering=1 writes line by line rather rather the default block for files
        #redirect stdout and stderr to the file
        sys.stdout = python_console_output_file
        sys.stderr = python_console_output_file
        
        print("", file=sys.stderr)
        print(datetime.now(UTC), file=sys.stdout)
        
        app = QApplication(sys.argv)
        app.setApplicationVersion("1.0.0") #the version must be changed for every release
        main_window = MainWindow()
        main_window.showMaximized()
        main_window.show()
        app.exec()
    
    #restore the original stdout and stderr
    sys.stdout = original_stdout
    sys.stderr = original_stderr
