idfplus.models.basetree
=======================

.. automodule:: idfplus.models.basetree
    :members:
    :undoc-members:
    :show-inheritance:
    :private-members:
    :special-members: __init__
