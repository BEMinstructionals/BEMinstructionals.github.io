idfplus.widgets package
=======================

.. automodule:: idfplus.widgets
    :members:
    :undoc-members:
    :show-inheritance:
    :private-members:
    :special-members: __init__

Submodules
----------

.. toctree::

   idfplus.widgets.main
   idfplus.widgets.prefs
   idfplus.widgets.search
   idfplus.widgets.setupwiz

