idfplus.delegates module
========================

.. automodule:: idfplus.delegates
    :members:
    :undoc-members:
    :show-inheritance:
    :private-members:
    :special-members: __init__
