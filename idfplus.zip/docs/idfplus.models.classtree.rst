idfplus.models.classtree
========================

.. automodule:: idfplus.models.classtree
    :members:
    :undoc-members:
    :show-inheritance:
    :private-members:
    :special-members: __init__
