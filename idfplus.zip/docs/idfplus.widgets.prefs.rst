idfplus.widgets.prefs
=====================

.. automodule:: idfplus.widgets.prefs
    :members:
    :undoc-members:
    :show-inheritance:
    :private-members:
    :special-members: __init__
