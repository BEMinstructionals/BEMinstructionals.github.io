idfplus.widgets.main
====================

.. automodule:: idfplus.widgets.main
    :members:
    :undoc-members:
    :show-inheritance:
    :private-members:
    :special-members: __init__
