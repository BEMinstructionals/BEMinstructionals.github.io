idfplus.models.classtable
=========================

.. automodule:: idfplus.models.classtable
    :members:
    :undoc-members:
    :show-inheritance:
    :private-members:
    :special-members: __init__
