idfplus.logger
==============

.. automodule:: idfplus.logger
    :members:
    :undoc-members:
    :show-inheritance:
    :private-members:
    :special-members: __init__
