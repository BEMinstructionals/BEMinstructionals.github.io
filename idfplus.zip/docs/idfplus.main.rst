idfplus.main
============

.. automodule:: idfplus.main
    :members:
    :undoc-members:
    :show-inheritance:
    :private-members:
    :special-members: __init__
