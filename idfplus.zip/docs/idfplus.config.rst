idfplus.config module
=====================

.. automodule:: idfplus.config
    :members:
    :undoc-members:
    :show-inheritance:
    :private-members:
    :special-members: __init__
