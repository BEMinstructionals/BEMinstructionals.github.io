idfplus.widgets.setupwiz
========================

.. automodule:: idfplus.widgets.setupwiz
    :members:
    :undoc-members:
    :show-inheritance:
    :private-members:
    :special-members: __init__
