idfplus.eplusio.iddmodel
========================

.. automodule:: idfplus.eplusio.iddmodel
    :members:
    :undoc-members:
    :show-inheritance:
    :private-members:
    :special-members: __init__, __getitem__

.. autoattribute:: idfplus.eplusio.iddmodel.IDDFile
    :annotation:
