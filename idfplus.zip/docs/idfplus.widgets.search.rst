idfplus.widgets.search
======================

.. automodule:: idfplus.widgets.search
    :members:
    :undoc-members:
    :show-inheritance:
    :private-members:
    :special-members: __init__
