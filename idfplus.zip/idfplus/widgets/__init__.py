#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Package containing various GUI widgets.

:copyright: (c) 2019 by Matt Doiron.
:license: GPL v3, see LICENSE for more details.
"""
