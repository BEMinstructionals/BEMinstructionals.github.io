#!/usr/bin/python
# -*- coding: utf-8 -*-
"""GUI-related data-models for tree and table views.

:copyright: (c) 2019 by Matt Doiron.
:license: GPL v3, see LICENSE for more details.
"""
